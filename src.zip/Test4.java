public class Test4 {
    public   char evaluateSeries(int a, int b) {
        int sum = 0;

        if (a <= 0 || b <= 0) {
            return 'X';
        }

        if (a >= b) {
            return 'Y';
        }

        // Tính tổng từ a đến b - thay thế i++ bằng i = i + 1
        for (int i = a; i < b; i = i + 1) {
            sum = sum + i;
        }

        // Phân loại kết quả
        if (sum > 100) {
            char result = 'A';
            return result;
        }
        else if (sum > 50) {
            char result = 'B';
            return result;
        }
        else {
            char result = 'C';
            return result;
        }
    }
}
