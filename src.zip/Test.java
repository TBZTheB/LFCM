public class Test {



    public   int i4_power(int i, int j) {
        int value;
        // Trường hợp khi j < 0
        if (j < 0) {
            if (i == 0) {
                return -1;  // 0 mũ số âm là không hợp lệ
            } else if (i == 1) {
                return 1;  // 1 mũ bất kỳ luôn là 1
            } else {
                return 0;  // Các số khác ngoài 0 và 1 mũ âm sẽ trả về 0
            }
        }
        // Trường hợp khi j == 0
        else if (j == 0) {
            return 1;  // Bất kỳ số nào mũ 0 đều là 1
        }
        // Trường hợp khi j > 0
        else {
            value = 1;
            for (int k = 1; k <= j; k++) {
                value *= i;  // Tính toán mũ i^j
            }
        }

        return value;
    }

    public int factorial(int x) {
        if (x <= 1) {// x<=1, error
            return 1;
        }
        int res = 1;
        for (int i = 2; i <= x; i++) {
            res *= i;
        }
        return res;
    }

    public   char evaluateSeries(int a, int b) {
        int sum = 0;

        if (a <= 0 || b <= 0) {
            return 'X';
        }

        if (a >= b) {
            return 'Y';
        }

        // Tính tổng từ a đến b - thay thế i++ bằng i = i + 1
        for (int i = a; i < b; i = i + 1) {
            sum = sum + i;
        }

        // Phân loại kết quả
        if (sum > 100) {
            char result = 'A';
            return result;
        }
        else if (sum > 50) {
            char result = 'B';
            return result;
        }
        else {
            char result = 'C';
            return result;
        }
    }

    // https://www.programiz.com/java-programming/examples/sum-natural-numbers
    // Calculates the sum of the first 'num' natural numbers using a while loop
    public   long sumNaturalNumbers(int num) {
        if (num < 1) {
            return 0; // Tổng là 0 nếu số lượng là 0 hoặc âm
        }
        int i = 1;
        long sum = 0; // Sử dụng long phòng trường hợp tổng lớn
        // Lặp khi i còn nhỏ hơn hoặc bằng num
        while(i <= num)
        {
            sum += i; // Cộng i vào tổng
            i++;      // Tăng i lên 1
        }
        return sum; // Trả về tổng tính được
    }

    public boolean areAmicableNumbers(int num1, int num2) {
        int sum1 = 0;
        int sum2 = 0;

        if (num1 <= 0 || num2 <= 0) {
            return false;
        }

        if (num1 == num2) {
            return false;
        }

        for (int i = 1; i < num1; i = i + 1) {
            if (num1 % i == 0) {
                sum1 = sum1 + i;
            }
        }

        for (int i = 1; i < num2; i = i + 1) {
            if (num2 % i == 0) {
                sum2 = sum2 + i;
            }
        }

        return (sum1 == num2 && sum2 == num1);
    }

    public   int combination(int n, int k) {
        if (k > n || k < 0) {
            return 0;
        }
        int res = 1;
        for (int i = 1; i <= k; i++) {
            res = res * (n - i + 1) / i;
        }
        return res;
    }

    public   double approximateSquareRoot(int number, int iterations) {
        double result = number / 2.0;

        if (number < 0 || iterations <= 0) {
            return -1.0;
        }

        if (number == 0 || number == 1) {
            return number;
        }

        for (int i = 0; i < iterations; i = i + 1) {
            result = 0.5 * (result + number / result);
        }

        return result;
    }

    //    // https://www.geeksforgeeks.org/java-program-to-check-if-a-number-is-prime-or-not/
//    // Function to check if a number is prime or not
    public   boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        int i = 2;
        while (i < n) {
            if (n % i == 0) {
                return false;
            }
            i++;
        }
        return true;
    }

    // https://www.programiz.com/java-programming/examples/count-number-of-digits
    // Function to count the number of digits in an integer
    public   int countDigits(long num) {
        // Trường hợp số 0 có 1 chữ số
        if (num == 0) {
            return 1;
        }
        int count = 0;
        // Sử dụng giá trị tuyệt đối để xử lý số âm
        long tempNum = Math.abs(num);
        // Lặp khi số vẫn còn lớn hơn 0
        while (tempNum > 0) {
            tempNum /= 10; // Bỏ đi chữ số cuối cùng
            ++count;       // Tăng bộ đếm
        }
        return count; // Trả về số lượng chữ số
    }

    public   boolean isPowerfulNumber(int num) {
        boolean isPowerful = true;

        if (num <= 0) {
            return false;
        }

        if (num == 1) {
            return true;
        }

        int temp = num;

        for (int i = 2; i <= temp; i = i + 1) {
            if (temp % i == 0) {
                int count = 0;

                while (temp % i == 0) {
                    count = count + 1;
                    temp = temp / i;
                }

                if (count < 2) {
                    isPowerful = false;
                }
            }
        }

        return isPowerful;
    }

    public   int sumOfDivisors(int number) {
        int sum = 0;

        if (number <= 0 || number > 10000) {
            return -1;
        }

        for (int i = 1; i <= number; i = i + 1) {
            if (number % i == 0) {
                sum = sum + i;
            }
        }

        return sum;
    }

    public   int fibonacciFor(int n) {
        if (n <= 1) return n;
        int a = 0, b = 1;
        for (int i = 2; i <= n; i++) {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    }

    public   char evaluatePerformance(int score1, int score2) {
        int total = 0;

        if (score1 < 0 || score2 < 0) {
            return 'I';
        }

        if (score1 > 100 || score2 > 100) {
            return 'I';
        }

        // Tính tổng điểm với trọng số
        for (int i = 1; i <= 2; i = i + 1) {
            if (i == 1) {
                total = total + score1 * 2;
            } else {
                total = total + score2 * 3;
            }
        }

        // Xếp loại học lực
        if (total >= 400) {
            char grade = 'A';
            return grade;
        }
        else if (total >= 300) {
            char grade = 'B';
            return grade;
        }
        else if (total >= 200) {
            char grade = 'C';
            return grade;
        }
        else {
            char grade = 'D';
            return grade;
        }
    }

    public   int findGCD(int a, int b) {
        int gcd = 1;

        if (a <= 0 || b <= 0) {
            return -1;
        }

        if (a == b) {
            return a;
        }

        int smaller = a;
        if (b < a) {
            smaller = b;
        }

        for (int i = 2; i <= smaller; i = i + 1) {
            if (a % i == 0 && b % i == 0) {
                gcd = i;
            }
        }

        return gcd;
    }


}

