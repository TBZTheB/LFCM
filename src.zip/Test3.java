public class Test3 {
    public   int factorial(int x) {
        if (x <= 1) {// x<=1, error
            return 1;
        }
        int res = 1;
        for (int i = 2; i <= x; i++) {
            res *= i;
        }
        return res;
    }
}
