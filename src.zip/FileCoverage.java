import cover.Cover;
import org.json.simple.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class để tính toán độ phủ trên toàn bộ tệp nguồn
 * Độ phủ tệp = trung bình cộng độ phủ của tất cả các hàm trong tệp
 */
public class FileCoverage {
    private String filePath;
    private List<Method> methods;
    private Map<String, Double> coverageMetrics;

    public FileCoverage(String filePath, List<Method> methods) {
        this.filePath = filePath;
        this.methods = methods;
        this.coverageMetrics = new HashMap<>();
        calculateFileCoverage();
    }

    /**
     * Tính toán độ phủ tệp cho C1, C2, C3
     */
    private void calculateFileCoverage() {
        double totalC1Coverage = 0.0;
        double totalC2Coverage = 0.0;
        double totalC3Coverage = 0.0;
        int methodCount = methods.size();

        for (Method method : methods) {
            Cover c1 = method.getCoverC1();
            Cover c2 = method.getCoverC2();
            Cover c3 = method.getCoverC3();
            
            // Tính phần trăm độ phủ cho mỗi tiêu chuẩn
            double c1Coverage = calculateCoveragePercentage(c1);
            double c2Coverage = calculateCoveragePercentage(c2);
            double c3Coverage = calculateCoveragePercentage(c3);
            
            totalC1Coverage += c1Coverage;
            totalC2Coverage += c2Coverage;
            totalC3Coverage += c3Coverage;
        }

        // Tính trung bình cộng độ phủ
        if (methodCount > 0) {
            coverageMetrics.put("C1", totalC1Coverage / methodCount);
            coverageMetrics.put("C2", totalC2Coverage / methodCount);
            coverageMetrics.put("C3", totalC3Coverage / methodCount);
        } else {
            coverageMetrics.put("C1", 0.0);
            coverageMetrics.put("C2", 0.0);
            coverageMetrics.put("C3", 0.0);
        }
    }

    /**
     * Tính phần trăm độ phủ cho một tiêu chuẩn
     */
    private double calculateCoveragePercentage(Cover cover) {
        int covered = cover.numberCovered();
        int total = cover.numberAllCovered();
        
        if (total > 0) {
            return ((double) covered / total) * 100.0;
        }
        return 0.0;
    }

    /**
     * Lấy độ phủ tệp cho một tiêu chuẩn cụ thể
     */
    public double getFileCoverage(String metric) {
        return coverageMetrics.getOrDefault(metric, 0.0);
    }

    /**
     * Xuất kết quả độ phủ tệp ra JSON
     */
    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("filePath", filePath);
        json.put("C1Coverage", String.format("%.2f%%", coverageMetrics.get("C1")));
        json.put("C2Coverage", String.format("%.2f%%", coverageMetrics.get("C2")));
        json.put("C3Coverage", String.format("%.2f%%", coverageMetrics.get("C3")));
        json.put("methodCount", methods.size());
        return json;
    }

    /**
     * Hiển thị báo cáo chi tiết độ phủ tệp
     */
    public String generateCoverageReport() {
        StringBuilder report = new StringBuilder();
        report.append("\n===== FILE COVERAGE REPORT =====\n");
        report.append("File: ").append(filePath).append("\n");
        report.append("Number of methods: ").append(methods.size()).append("\n\n");
        
        report.append("Overall File Coverage:\n");
        report.append("Statement Coverage (C1): ").append(String.format("%.2f%%", coverageMetrics.get("C1"))).append("\n");
        report.append("Branch Coverage (C2): ").append(String.format("%.2f%%", coverageMetrics.get("C2"))).append("\n");
        report.append("MC/DC Coverage (C3): ").append(String.format("%.2f%%", coverageMetrics.get("C3"))).append("\n\n");
        
        report.append("Method Level Coverage:\n");
        
        for (Method method : methods) {
            Cover c1 = method.getCoverC1();
            Cover c2 = method.getCoverC2();
            Cover c3 = method.getCoverC3();
            
            double c1Percentage = calculateCoveragePercentage(c1);
            double c2Percentage = calculateCoveragePercentage(c2);
            double c3Percentage = calculateCoveragePercentage(c3);
            
            report.append("  - ").append(method.getMethodName()).append(":\n");
            report.append("    C1: ").append(" (").append(String.format("%.2f%%", c1Percentage)).append(")\n");
            report.append("    C2: ").append(" (").append(String.format("%.2f%%", c2Percentage)).append(")\n");
            report.append("    C3: ").append(" (").append(String.format("%.2f%%", c3Percentage)).append(")\n");
        }
        
        return report.toString();
    }
}