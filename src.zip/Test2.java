public class Test2 {
    public   long sumNaturalNumbers(int num) {
        if (num < 1) {
            return 0; // Tổng là 0 nếu số lượng là 0 hoặc âm
        }
        int i = 1;
        long sum = 0; // Sử dụng long phòng trường hợp tổng lớn
        // Lặp khi i còn nhỏ hơn hoặc bằng num
        while(i <= num)
        {
            sum += i; // Cộng i vào tổng
            i++;      // Tăng i lên 1
        }
        return sum; // Trả về tổng tính được
    }
}
