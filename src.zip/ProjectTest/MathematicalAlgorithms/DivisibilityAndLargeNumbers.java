package ProjectTest.MathematicalAlgorithms;

public class DivisibilityAndLargeNumbers {
    public boolean check3(String str)
    {
        // Compute sum of digits
        int n = str.length();
        int digitSum = 0;
        for (int i=0; i<n; i++)
            digitSum += (str.charAt(i)-'0');

        // Check if sum of digits is
        // divisible by 3.
        return (digitSum % 3 == 0);
    }

    public boolean check4(String str)
    {
        int n = str.length();

        // Empty string
        if (n == 0)
            return false;

        // If there is single digit
        if (n == 1)
            return ((str.charAt(0) - '0') % 4 == 0);

        // If number formed by last two digits is
        // divisible by 4.
        int last = str.charAt(n - 1) - '0';
        int second_last = str.charAt(n - 2) - '0';
        return ((second_last * 10 + last) % 4 == 0);
    }

    public boolean check6(String str)
    {
        int n = str.length();

        // Return false if number is not divisible by 2.
        if ((str.charAt(n-1) -'0')%2 != 0)
            return false;

        // If we reach here, number is divisible by 2.
        // Now check for 3.

        // Compute sum of digits
        int digitSum = 0;
        for (int i=0; i<n; i++)
            digitSum += (str.charAt(i)-'0');

        // Check if sum of digits is divisible by 3
        return (digitSum % 3 == 0);
    }

    public static boolean isDivBy7(int n)
    {
        if (n == 0)
            return true;
        while (n >= 7) {
            n -= 7;
        }
        return n == 0;
    }

    public boolean isDvisibleBy12(String num)
    {
        // if number greater than 3
        if (num.length() >= 3) {

            // find last digit
            int d1 = (int)num.charAt(num.length() - 1);

            // no is odd
            if (d1 % 2 != 0)
                return false;

            // find second last digit
            int d2 = (int)num.charAt(num.length() - 2);

            // find sum of all digits
            int sum = 0;
            for (int i = 0; i < num.length(); i++)
                sum += num.charAt(i);

            return (sum % 3 == 0 &&
                    (d2 * 10 + d1) % 4 == 0);
        }

        else {

            // if number is less than
            // or equal to 100
            int number = Integer.parseInt(num);
            return (number % 12 == 0);
        }
    }

}
