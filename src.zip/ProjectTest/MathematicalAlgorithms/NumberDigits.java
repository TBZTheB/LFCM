package ProjectTest.MathematicalAlgorithms;

public class NumberDigits {
    public int digitSum(long n)
    {
        int digSum = 0;
        while (n > 0)
        {
            digSum += n % 10;
            n /= 10;
        }
        return digSum;
    }

    public boolean checkUtil(int num, int dig, int base)
    {
        // Base case
        if (dig==1 && num < base)
            return true;

        // If there are more than 1 digits
        // left and number is more than base,
        // then remove last digit by doing num/base,
        //  reduce the number of digits and recur
        if (dig > 1 && num >= base)
            return checkUtil(num / base, --dig, base);

        return false;
    }

    public boolean checkJumbled(int num)
    {
        // Single digit number
        if (num / 10 == 0)
            return true;

        // Checking every digit
        // through a loop
        while (num != 0)
        {

            // All digits were checked
            if (num / 10 == 0)
                return true;

            // Digit at index i
            int digit1 = num % 10;

            // Digit at index i-1
            int digit2 = (num / 10) % 10;

            // If difference is
            // greater than 1
            if (Math.abs(digit2 - digit1) > 1)
                return false;

            num = num / 10;
        }

        // Number checked
        return true;
    }
    public int kthDigit(int a, int b, int k)
    {
        // Computing a^b
        int p = (int)Math.pow(a, b);

        int count = 0;
        while (p > 0 && count < k) {

            // Getting last digit
            int rem = p % 10;

            // Increasing count by 1
            count++;

            // If current number is required digit
            if (count == k)
                return rem;

            // Remove last digit
            p = p / 10;
        }

        return 0;
    }

}
