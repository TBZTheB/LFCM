package ProjectTest.MathematicalAlgorithms;

public class NumberSystem {
    public boolean isPowerOfK(int n,int k)
    {
        // loop to change base n to base = k
        boolean oneSeen = false;
        while (n > 0)
        {

            // Find current digit in base k
            int digit = n % k;

            // If digit is neither 0 nor 1
            if (digit > 1)
                return false;

            // Make sure that only one 1
            // is present.
            if (digit == 1)
            {
                if (oneSeen)
                    return false;
                oneSeen = true;
            }

            n /= k;
        }

        return true;
    }

    public int val(char c)
    {
        if (c >= '0' && c <= '9')
            return (int)c - '0';
        else
            return (int)c - 'A' + 10;
    }

    public String decToBin(int n)
    {
        if (n == 0)
            return "0";

        // to store the binary
        // equivalent of decimal
        String bin = "";

        while (n > 0)
        {
            // to get the last binary digit
            // of the number 'n' and accumulate
            // it at the beginning of 'bin'
            bin = ((n & 1) == 0 ? '0' : '1') + bin;

            // right shift 'n' by 1
            n >>= 1;
        }

        // required binary number
        return bin;
    }


}
