package ProjectTest.MathematicalAlgorithms;

public class Series {
    public int getSum(int n)
    {
        int sum = 0; // 1 is a proper divisor

        // Note that this loop runs till
        // square root of n
        for (int i = 1; i <= Math.sqrt(n); i++)
        {
            if (n % i == 0)
            {
                // If divisors are equal, take only one
                // of them
                if (n / i == i)
                {
                    sum = sum + i;
                }
                else // Otherwise take both
                {
                    sum = sum + i;
                    sum = sum + (n / i);
                }
            }
        }

        // calculate sum of all proper divisors only
        return sum - n;
    }

    public int gen(int n)
    {

        // S(0) = 0
        if (n == 0)
            return 0;

            // S(1) = 1
        else if (n == 1)
            return 1;

            // S(2 * n) = 4 * S(n)
        else if (n % 2 == 0)
            return 4 * gen(n / 2);

            // S(2 * n + 1) = 4 * S(n) + 1
        else if (n % 2 == 1)
            return 4 * gen(n / 2) + 1;
        return 0;
    }

    public int sumOfSeries(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++)
            sum = sum + (2 * i - 1) * (2 * i - 1);
        return sum;
    }

}
