package ProjectTest.MathematicalAlgorithms;

//https://www.geeksforgeeks.org/mathematical-algorithms/
public class GCDandLCM {

    public int gcd(int a, int b)
    {
        // Find Minimum of a and b
        int result = Math.min(a, b);
        while (result > 0) {
            if (a % result == 0 && b % result == 0) {
                break;
            }
            result = result - 1;
        }

        // Return gcd of a and b
        return result;
    }

    public int findLCM(int a, int b)
    {
        int count = 0;
        int greater = Math.max(a, b);
        int smallest = Math.min(a, b);
        for (int i = smallest;i <= greater; i += 1) {
            if (i % smallest == 0)
                count = count + 1;
        }
        return count;
    }

    public static int findGCD(int a, int b) {
        int gcd = 1;

        if (a <= 0 || b <= 0) {
            return -1;
        }

        if (a == b) {
            return a;
        }

        int smaller = a;
        if (b < a) {
            smaller = b;
        }

        for (int i = 2; i <= smaller; i = i + 1) {
            if (a % i == 0 && b % i == 0) {
                gcd = i;
            }
        }

        return gcd;
    }
    static int CountPairs(int n) {

        // initialize k
        int k = n;

        // loop till imin <= n
        int imin = 1;

        // Initialize result
        int ans = 0;

        while (imin <= n) {

            // max i with given k floor(n/k)
            int imax = n / k;

            // adding k*(number of i with
            // floor(n/i) = k to ans
            ans += k * (imax - imin + 1);

            // set imin = imax + 1
            // and k = n/imin
            imin = imax + 1;
            k = n / imin;
        }

        return ans;
    }

    public double gcd2(double a, double b)
    {
        if (a < b)
            return gcd2(b, a);

        // base case
        if (Math.abs(b) < 0.001)
            return a;

        else
            return (gcd2(b, a -
                    Math.floor(a / b) * b));
    }



}
