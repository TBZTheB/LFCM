package ProjectTest.MathematicalAlgorithms;

public class Algebra {

    static int _log(double x,
                    double base)
    {
        return (int)(Math.log(x) /
                Math.log(base));
    }

    public int countIntegralSolutions(int n)
    {
        // Initialize result
        int result = 0;

        // Consider all triplets and increment
        // result whenever sum of a triplet is n.
        for (int i = 0; i <= n; i++)
            for (int j = 0; j <= n - i; j++)
                for (int k = 0; k <= (n - i - j); k++)
                    if (i + j + k == n)
                        result++;

        return result;
    }
}
