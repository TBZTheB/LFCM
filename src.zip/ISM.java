import cfg.generation.testpath.Check.FullTestpaths;
import cfg.nodes.ICfgNode;
import cover.Cover;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import solvingConditions.ConstraintSolver;
import solvingConditions.Variable;
import symbolicExecution.SymbolicExecutionTestpath;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.*;

public class ISM {
    private String folderPath;
    private Map<String, FileMetrics> fileMetricsMap;
    private DecimalFormat decimalFormat;

    public ISM(String folderPath) {
        this.folderPath = folderPath;
        this.fileMetricsMap = new HashMap<>();
        this.decimalFormat = new DecimalFormat("#.##");
    }

    /**
     * Khởi chạy quá trình sinh dữ liệu kiểm thử cho thư mục
     */
    public void generateTestcase() throws IOException {
        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";

        // Tạo thư mục kết quả nếu chưa tồn tại
        createResultDirectories(currentPath);

        // Thống kê toàn bộ
        long startTime = System.currentTimeMillis();
        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long memoryBefore = runtime.totalMemory() - runtime.freeMemory();

        // Lấy danh sách các file Java trong thư mục
        List<Path> filePathList = getJavaFilesInFolder(Paths.get(folderPath));
        System.out.println("Tìm thấy " + filePathList.size() + " file Java trong thư mục " + folderPath);

        // Xử lý từng file
        for (Path filePath : filePathList) {
            processFile(filePath.toString());
        }

        // Tính toán và hiển thị kết quả
        generateSummaryReport();

        // Tính thời gian và bộ nhớ tổng cộng
        long endTime = System.currentTimeMillis();
        double duration = (endTime - startTime);
        double memoryAfter = runtime.totalMemory() - runtime.freeMemory();
        double memoryUsed = (memoryAfter - memoryBefore) / (1024.0 * 1024.0);

        System.out.println("\n===== THỐNG KÊ TỔNG THỂ =====");
        System.out.println("Tổng số tệp: " + filePathList.size());
        System.out.println("Tổng thời gian thực thi: " + duration + " milliseconds");
        System.out.println("Tổng bộ nhớ sử dụng: " + decimalFormat.format(memoryUsed) + " MB");
    }

    /**
     * Tạo các thư mục kết quả cần thiết
     */
    private void createResultDirectories(String currentPath) {
        // Tạo thư mục result và các thư mục con nếu chưa tồn tại
        String[] dirs = {
                currentPath + "JdtBase/src/result",
                currentPath + "JdtBase/src/result/marks",
                currentPath + "JdtBase/src/result/reports"
        };

        for (String dir : dirs) {
            File directory = new File(dir);
            if (!directory.exists()) {
                directory.mkdirs();
            }
        }
    }

    /**
     * Lấy danh sách các file Java trong thư mục
     */
    private List<Path> getJavaFilesInFolder(Path folderPath) {
        List<Path> javaFiles = new ArrayList<>();
        try {
            if (Files.exists(folderPath) && Files.isDirectory(folderPath)) {
                Files.walk(folderPath)
                        .filter(path -> path.toString().endsWith(".java"))
                        .forEach(javaFiles::add);
            }
        } catch (IOException e) {
            System.err.println("Lỗi khi quét thư mục: " + e.getMessage());
        }
        return javaFiles;
    }

    /**
     * Xử lý từng file Java
     */
    private void processFile(String filePath) throws IOException {
        System.out.println("\n===== ĐANG XỬ LÝ FILE: " + new File(filePath).getName() + " =====");

        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";

        // Tạo TestDriver cho file
        TestDriver testDriver = new TestDriverISM(filePath);
        testDriver.doTestDriver();
        testDriver.compileTestDriver();

        // Lấy danh sách các phương thức trong file
        List<Method> methodList = testDriver.getMethods();
        if (methodList.isEmpty()) {
            System.out.println("Không tìm thấy phương thức nào trong file " + filePath);
            return;
        }

        String fileName = new File(filePath).getName().replace(".java", "");
        FileMetrics fileMetrics = new FileMetrics(fileName, methodList.size());

        // Xử lý từng phương thức
        for (Method method : methodList) {
            // Đo thời gian và bộ nhớ cho từng phương thức
            long methodStartTime = System.currentTimeMillis();
            Runtime runtime = Runtime.getRuntime();
            runtime.gc();
            long methodMemoryBefore = runtime.totalMemory() - runtime.freeMemory();

            // Sinh test case cho từng tệp gống bên LFCM.java
            processMethodTestcases(method, testDriver, currentPath);

            // Đo thời gian và bộ nhớ sau khi hoàn thành xử lý phương thức
            long methodEndTime = System.currentTimeMillis();
            long methodMemoryAfter = runtime.totalMemory() - runtime.freeMemory();

            double methodDuration = (methodEndTime - methodStartTime);
            double methodMemoryUsed = (methodMemoryAfter - methodMemoryBefore) / (1024.0 * 1024.0);

            // Lưu thông tin về độ phủ và tài nguyên sử dụng
            MethodMetrics methodMetrics = new MethodMetrics(
                    method.getMethodName().toString(),
                    getCoveragePercentage(method.getCoverC1()),
                    getCoveragePercentage(method.getCoverC2()),
                    getCoveragePercentage(method.getCoverC3()),
                    methodDuration,
                    methodMemoryUsed
            );
            fileMetrics.addMethodMetrics(methodMetrics);

            // In thông tin chi tiết về từng phương thức
            System.out.println("\n" + method.getMethodName() + ":");
            System.out.println("C1: (" + decimalFormat.format(methodMetrics.getC1Coverage()) + "%)");
            System.out.println("C2: (" + decimalFormat.format(methodMetrics.getC2Coverage()) + "%)");
            System.out.println("C3: (" + decimalFormat.format(methodMetrics.getC3Coverage()) + "%)");
            System.out.println("Run: " + methodDuration + " milliseconds");
            System.out.println("Used memory: " + decimalFormat.format(methodMemoryUsed) + "MB");
        }

        // Tính toán các chỉ số tổng hợp cho file: độ phủ trung bình, thời gian và bộ nhớ
        fileMetrics.calculateAggregatedMetrics();
        fileMetricsMap.put(fileName, fileMetrics);

        // Lưu file metrics vào JSON
        String jsonFilePath = currentPath + "JdtBase/src/result/reports/" + fileName + "_metrics.json";
        saveFileMetricsToJson(fileMetrics, jsonFilePath);
    }

    /**
     * Xử lý sinh testcase cho một phương thức
     */
    private void processMethodTestcases(Method method, TestDriver testDriver, String currentPath) throws IOException {
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonMethod = new JSONArray();

        // Sinh test case ngẫu nhiên ban đầu
        List<Variable> testcaseRandom = method.randomTestcase();
        method.getTestcases().add(testcaseRandom);

        String filepathMark = currentPath + "JdtBase/src/result/marks/" + method.getMethodName() + "Marks/TestDriverResult"
                + (method.getAllTestcases().size() + method.getTestcases().size()) + ".txt";
        jsonMethod.add(addTestcaseJsonMethod(testcaseRandom, filepathMark));
        jsonObject.put(method.getMethodName(), jsonMethod);

        writeFileJson(currentPath + "JdtBase/src/result/Testcases.json", jsonObject);
        testDriver.runTestDriver();
        method.readMarkV1(false, false, false);

        // Sinh các test case để tăng độ phủ
        boolean check = true;
        int iteration = 0;
        int maxIterations = 10; // Giới hạn số lần lặp để tránh vòng lặp vô hạn

        while (check && iteration < maxIterations) {
            iteration++;
            check = false;
            boolean checkC1 = true;
            boolean checkC2 = true;
            boolean checkC3 = true;

            jsonObject = new JSONObject();
            jsonMethod = new JSONArray();
            FullTestpaths testpaths = method.getTestpaths();

            while (!testpaths.isEmpty()) {
                List<ICfgNode> testpath = testpaths.get(0).getAllCfgNodes();
                checkC1 = method.getCoverC1().checkCoveredTestpath(testpath);
                checkC2 = method.getCoverC2().checkCoveredTestpath(testpath);
                checkC3 = method.getCoverC3().checkCoveredTestpath(testpath);

                if (!checkC1 || !checkC2 || !checkC3) {
                    SymbolicExecutionTestpath sym = new SymbolicExecutionTestpath(
                            testpaths.get(0).getAllCfgNodes(), method.getParameters());
                    List<Expression> conditions = sym.symbolicExecution();

                    if (!conditions.isEmpty() && !conditions.get(0).toString().equals("false")) {
                        ConstraintSolver constraintSolver = new ConstraintSolver(
                                conditions, method.getParameters(), currentPath);
                        List<Variable> result = constraintSolver.solveConditions();
                        List<Variable> testcase = new ArrayList<>();

                        for (Object parameter : method.getParameters()) {
                            for (Variable variable : result) {
                                if (((SingleVariableDeclaration) parameter).getName().toString().equals(variable.getName())) {
                                    variable.setType(((SingleVariableDeclaration) parameter).getType().toString());
                                    testcase.add(variable);
                                }
                            }
                        }

                        if (!testcase.isEmpty()) {
                            method.getTestcases().add(testcase);
                            filepathMark = currentPath + "JdtBase/src/result/marks/" + method.getMethodName() + "Marks/TestDriverResult"
                                    + (method.getAllTestcases().size() + method.getTestcases().size()) + ".txt";

                            jsonMethod.add(addTestcaseJsonMethod(testcase, filepathMark));
                            jsonObject.put(method.getMethodName(), jsonMethod);

                            check = true;
                            testpaths.remove(0);
                            break;
                        }
                    }
                }
                testpaths.remove(0);
            }

            if (check) {
                writeFileJson(currentPath + "JdtBase/src/result/Testcases.json", jsonObject);
                testDriver.runTestDriver();
                method.readMarkV1(checkC1, checkC2, checkC3);
            }
        }

        // Nếu phương thức có vòng lặp, thực hiện phân tích vòng lặp
//        if (method.hasLoop()) {
//            analyzeLoop(method);
//        }
    }


    /**
     * Tạo báo cáo tổng hợp cho tất cả các file
     */
    private void generateSummaryReport() {
        System.out.println("\n===== BÁO CÁO TỔNG HỢP =====");
        System.out.println(String.format("%-25s %-15s %-15s %-15s %-15s %-20s %-15s",
                "Tên tệp", "Số unit", "Độ phủ C1 (%)", "Độ phủ C2 (%)", "Độ phủ C3 (%)",
                "Thời gian (ms)", "Bộ nhớ (MB)"));
        System.out.println("------------------------------------------------------------------------------------------------");

        JSONArray reportArray = new JSONArray();

        for (FileMetrics metrics : fileMetricsMap.values()) {
            System.out.println(String.format("%-25s %-15d %-15s %-15s %-15s %-20.0f %-15s",
                    metrics.getFileName(),
                    metrics.getUnitCount(),
                    decimalFormat.format(metrics.getC1Coverage()),
                    decimalFormat.format(metrics.getC2Coverage()),
                    decimalFormat.format(metrics.getC3Coverage()),
                    metrics.getTotalExecutionTime(),
                    decimalFormat.format(metrics.getTotalMemoryUsage())));

            // Thêm thông tin vào JSON để lưu trữ
            JSONObject fileObj = new JSONObject();
            fileObj.put("fileName", metrics.getFileName());
            fileObj.put("unitCount", metrics.getUnitCount());
            fileObj.put("c1Coverage", decimalFormat.format(metrics.getC1Coverage()));
            fileObj.put("c2Coverage", decimalFormat.format(metrics.getC2Coverage()));
            fileObj.put("c3Coverage", decimalFormat.format(metrics.getC3Coverage()));
            fileObj.put("executionTime", metrics.getTotalExecutionTime());
            fileObj.put("memoryUsage", decimalFormat.format(metrics.getTotalMemoryUsage()));
            reportArray.add(fileObj);
        }

        // Lưu báo cáo tổng hợp vào file JSON
        try {
            String currentPath = Paths.get("").toAbsolutePath().toString().replace("\\", "/") + "/";
            String jsonFilePath = currentPath + "JdtBase/src/result/reports/summary_report.json";

            File jsonFile = new File(jsonFilePath);
            try (FileWriter fileWriter = new FileWriter(jsonFile)) {
                fileWriter.write(reportArray.toString());
                System.out.println("\nĐã lưu báo cáo tổng hợp tại: " + jsonFilePath);
            }
        } catch (IOException e) {
            System.err.println("Lỗi khi lưu báo cáo tổng hợp: " + e.getMessage());
        }
    }

    /**
     * Lưu thông tin metrics của file vào JSON
     */
    private void saveFileMetricsToJson(FileMetrics metrics, String filePath) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("fileName", metrics.getFileName());
        jsonObject.put("unitCount", metrics.getUnitCount());
        jsonObject.put("c1Coverage", decimalFormat.format(metrics.getC1Coverage()));
        jsonObject.put("c2Coverage", decimalFormat.format(metrics.getC2Coverage()));
        jsonObject.put("c3Coverage", decimalFormat.format(metrics.getC3Coverage()));
        jsonObject.put("totalExecutionTime", metrics.getTotalExecutionTime());
        jsonObject.put("totalMemoryUsage", decimalFormat.format(metrics.getTotalMemoryUsage()));

        // Thêm thông tin chi tiết về từng phương thức
        JSONArray methodsArray = new JSONArray();
        for (MethodMetrics methodMetrics : metrics.getMethodMetrics()) {
            JSONObject methodObj = new JSONObject();
            methodObj.put("methodName", methodMetrics.getMethodName());
            methodObj.put("c1Coverage", decimalFormat.format(methodMetrics.getC1Coverage()));
            methodObj.put("c2Coverage", decimalFormat.format(methodMetrics.getC2Coverage()));
            methodObj.put("c3Coverage", decimalFormat.format(methodMetrics.getC3Coverage()));
            methodObj.put("executionTime", methodMetrics.getExecutionTime());
            methodObj.put("memoryUsage", decimalFormat.format(methodMetrics.getMemoryUsage()));
            methodsArray.add(methodObj);
        }
        jsonObject.put("methods", methodsArray);

        try (FileWriter fileWriter = new FileWriter(filePath)) {
            fileWriter.write(jsonObject.toString());
        } catch (IOException e) {
            System.err.println("Lỗi khi lưu file metrics: " + e.getMessage());
        }
    }

    /**
     * Tính phần trăm độ phủ
     */
    private double getCoveragePercentage(Cover cover) {
        if (cover.numberAllCovered() == 0) return 100.0;
        return ((double) cover.numberCovered() / cover.numberAllCovered()) * 100.0;
    }

    /**
     * Tạo JSON object cho testcase
     */
    public static JSONObject addTestcaseJsonMethod(List<Variable> testcase, String filepath) {
        JSONObject jsonTestpath = new JSONObject();
        JSONArray jsonTestcase = new JSONArray();

        for (Variable variable : testcase) {
            JSONObject jsonVar = new JSONObject();
            jsonVar.put("name", variable.getName());
            jsonVar.put("type", variable.getType());
            jsonVar.put("value", variable.getValue());
            jsonTestcase.add(jsonVar);
        }

        jsonTestpath.put("testcase", jsonTestcase);
        jsonTestpath.put("filepath", filepath);
        return jsonTestpath;
    }

    /**
     * Ghi đối tượng JSON vào file
     */
    public static void writeFileJson(String filepath, JSONObject jsonObject) {
        File jsonFile = new File(filepath);
        if (jsonFile.exists()) {
            jsonFile.delete();
        }

        File parentDir = jsonFile.getParentFile();
        if (!parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (FileWriter fileWriter = new FileWriter(jsonFile)) {
            fileWriter.write(jsonObject.toString());
        } catch (IOException e) {
            System.err.println("Lỗi khi ghi file JSON: " + e.getMessage());
        }
    }

    /**
     * Lớp lưu trữ các metrics của một phương thức
     */
    private class MethodMetrics {
        private String methodName;
        private double c1Coverage;
        private double c2Coverage;
        private double c3Coverage;
        private double executionTime;
        private double memoryUsage;

        public MethodMetrics(String methodName, double c1Coverage, double c2Coverage, double c3Coverage,
                             double executionTime, double memoryUsage) {
            this.methodName = methodName;
            this.c1Coverage = c1Coverage;
            this.c2Coverage = c2Coverage;
            this.c3Coverage = c3Coverage;
            this.executionTime = executionTime;
            this.memoryUsage = memoryUsage;
        }

        public String getMethodName() {
            return methodName;
        }

        public double getC1Coverage() {
            return c1Coverage;
        }

        public double getC2Coverage() {
            return c2Coverage;
        }

        public double getC3Coverage() {
            return c3Coverage;
        }

        public double getExecutionTime() {
            return executionTime;
        }

        public double getMemoryUsage() {
            return memoryUsage;
        }
    }

    /**
     * Lớp lưu trữ các metrics của một file
     */
    private class FileMetrics {
        private String fileName;
        private int unitCount;
        private List<MethodMetrics> methodMetrics;
        private double c1Coverage;
        private double c2Coverage;
        private double c3Coverage;
        private double totalExecutionTime;
        private double totalMemoryUsage;

        public FileMetrics(String fileName, int unitCount) {
            this.fileName = fileName;
            this.unitCount = unitCount;
            this.methodMetrics = new ArrayList<>();
        }

        public void addMethodMetrics(MethodMetrics metrics) {
            methodMetrics.add(metrics);
        }

        public void calculateAggregatedMetrics() {
            if (methodMetrics.isEmpty()) return;

            // Tính trung bình độ phủ
            double totalC1 = 0;
            double totalC2 = 0;
            double totalC3 = 0;

            // Tính tổng thời gian và bộ nhớ
            double totalTime = 0;
            double totalMemory = 0;

            for (MethodMetrics metrics : methodMetrics) {
                totalC1 += metrics.getC1Coverage();
                totalC2 += metrics.getC2Coverage();
                totalC3 += metrics.getC3Coverage();
                totalTime += metrics.getExecutionTime();
                totalMemory += metrics.getMemoryUsage();
            }

            this.c1Coverage = totalC1 / methodMetrics.size();
            this.c2Coverage = totalC2 / methodMetrics.size();
            this.c3Coverage = totalC3 / methodMetrics.size();
            this.totalExecutionTime = totalTime;
            this.totalMemoryUsage = totalMemory;
        }

        public String getFileName() {
            return fileName;
        }

        public int getUnitCount() {
            return unitCount;
        }

        public List<MethodMetrics> getMethodMetrics() {
            return methodMetrics;
        }

        public double getC1Coverage() {
            return c1Coverage;
        }

        public double getC2Coverage() {
            return c2Coverage;
        }

        public double getC3Coverage() {
            return c3Coverage;
        }

        public double getTotalExecutionTime() {
            return totalExecutionTime;
        }

        public double getTotalMemoryUsage() {
            return totalMemoryUsage;
        }
    }
}