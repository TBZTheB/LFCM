package symbolicExecution;

public class VariableFormat {
    Variable variable;
    
}
