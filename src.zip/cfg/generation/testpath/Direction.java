package cfg.generation.testpath;

public enum Direction {
    FALSE,
    TRUE,
}
