package cfg.generation.testpath;

public class TestpathGenerationConfig {
    public static double maxIterationsforEachLoop = 1;
}
