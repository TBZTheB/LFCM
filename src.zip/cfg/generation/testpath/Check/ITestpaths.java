package cfg.generation.testpath.Check;

public interface ITestpaths {
//    ITestpath getLongestTestpath();
//
//    Testpaths cast();
}
