package cfg.nodes;

import org.eclipse.jdt.core.dom.Statement;

public class ExpressionStatementCfgNode extends SimpleCfgNode{

    public ExpressionStatementCfgNode (Statement _statement) {
        super(_statement);
    }

}
