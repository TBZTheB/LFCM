package cfg.nodes;

public class ForwardCfgNode extends CfgNode{
}
