package cfg.nodes;

import org.eclipse.jdt.core.dom.Expression;
public class ForUpdaterCfgNode extends SimpleCfgNode{
    public ForUpdaterCfgNode(Expression expression){
        super(expression);
    }
}
