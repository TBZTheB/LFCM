package cfg.nodes;

public class HasMoreNode extends FlagCfgNode{
    public  HasMoreNode(){
        super();
        this.setContent("HasMoreNode");
    }
}
