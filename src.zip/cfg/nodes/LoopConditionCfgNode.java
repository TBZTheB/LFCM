package cfg.nodes;

import org.eclipse.jdt.core.dom.Expression;

public class LoopConditionCfgNode extends ConditionCfgNode{
    public LoopConditionCfgNode(Expression condition) {
        super(condition);
    }
    public Expression getLoopCondition() {
        return this.getAstCondition();
    }
    // Mặc định là vòng lặp for
    public boolean isForLoop() {
        return false;
    }

    // Phương thức kiểm tra while-loop (ghi đè ở lớp con)
    public boolean isWhileLoop() {
        return false;
    }

    // Phương thức kiểm tra do-while-loop (ghi đè ở lớp con)
    public boolean isDoWhileLoop() {
        return false;
    }

}
