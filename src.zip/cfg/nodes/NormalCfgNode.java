package cfg.nodes;

public class NormalCfgNode extends CfgNode {
}
