package cfg.nodes;

public class BeginFlagCfgNode extends FlagCfgNode {
    public  BeginFlagCfgNode(){
        super();
        this.setContent("Begin");
    }
}
