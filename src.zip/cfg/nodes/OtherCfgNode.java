package cfg.nodes;

import org.eclipse.jdt.core.dom.Statement;

public class OtherCfgNode extends SimpleCfgNode {
    public OtherCfgNode(Statement statement) {
        super(statement);
    }
}
