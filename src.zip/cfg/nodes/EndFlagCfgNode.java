package cfg.nodes;

public class EndFlagCfgNode extends FlagCfgNode{
    public  EndFlagCfgNode(){
        super();
        this.setContent("End");
    }
}
