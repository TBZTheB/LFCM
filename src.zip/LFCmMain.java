import java.io.IOException;
import java.nio.file.Paths;

public class LFCmMain {
    public static void main(String[] args) throws IOException {
        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";

        String filePath = currentPath + "JdtBase/src/Test3.java";
        LFCm lfcm = new LFCm(filePath);
        lfcm.generateTestcase();
    }

}
