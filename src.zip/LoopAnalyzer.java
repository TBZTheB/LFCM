/**
 * LoopAnalyzer is responsible for analyzing loops in Java methods and generating
 * test cases to achieve specific coverage criteria for loops:
 *
 * 1. 0 iterations (bypass the loop entirely)
 * 2. Exactly 1 iteration
 * 3. m iterations (where m < n, n being the maximum iterations)
 * 4. n-1 iterations (one less than maximum)
 * 5. n iterations (maximum)
 * 6. n+1 iterations (one more than maximum, typically impossible due to loop condition)
 *
 * The analyzer works by:
 * 1. Detecting loops in the CFG
 * 2. Determining loop properties (start value, end value, step)
 * 3. Identifying variables that influence the loop behavior
 * 4. Generating test cases using symbolic execution and constraint solving
 * 5. Validating that test cases achieve the expected coverage
 */
import cfg.nodes.*;
import org.eclipse.jdt.core.dom.*;
import symbolicExecution.SymbolicExecutionTestpath;
import solvingConditions.ConstraintSolver;
import solvingConditions.Variable;

import java.util.*;

/**
 * Lớp phân tích vòng lặp thông qua thực thi tượng trưng và giải điều kiện ràng buộc
 */
public class LoopAnalyzer {
    private Method method;
    private List<LoopInfo> detectedLoops;

    public LoopAnalyzer(Method method) {
        this.method = method;
        this.detectedLoops = new ArrayList<>();
    }
    
    /**
     * Phát hiện tất cả các vòng lặp trong phương thức
     */
    public List<LoopInfo> detectLoops() {
        for (ICfgNode node : method.getAllStatements()) {
            if (node instanceof LoopConditionCfgNode) {
                LoopConditionCfgNode loopNode = (LoopConditionCfgNode) node;
                LoopInfo loopInfo = analyzeLoop(loopNode);
                if (loopInfo != null) {
                    detectedLoops.add(loopInfo);
                }
            }
        }
        return detectedLoops;
    }

    /**
     * Phân tích một vòng lặp cụ thể và trả về thông tin
     */
    private LoopInfo analyzeLoop(LoopConditionCfgNode loopNode) {
        LoopInfo loopInfo = new LoopInfo();
        loopInfo.setLoopNode(loopNode);

        // Phân tích cú pháp vòng lặp
        Expression condition = loopNode.getLoopCondition();
        loopInfo.setConditionExpr(condition);

        // Xác định biến lặp (iterator variable)
        String iteratorVar = extractIteratorVariable(condition);
        loopInfo.setIteratorVariable(iteratorVar);

        // Tìm cả tham số bắt đầu và kết thúc của vòng lặp
        if (condition instanceof InfixExpression) {
            InfixExpression infixExpr = (InfixExpression) condition;
            Expression leftOp = infixExpr.getLeftOperand();
            Expression rightOp = infixExpr.getRightOperand();

            // Kiểm tra xem bên phải có phải là tham số không
            if (rightOp instanceof SimpleName) {
                String rightVarName = ((SimpleName) rightOp).getIdentifier();

                // Kiểm tra xem đây có phải tham số của phương thức không
                for (Object param : method.getParameters()) {
                    SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
                    if (parameter.getName().getIdentifier().equals(rightVarName)) {
                        loopInfo.setLoopParameter(rightVarName); // Tham số kết thúc
                        break;
                    }
                }
            }
        }

        // Xác định giá trị khởi tạo - tìm tham số bắt đầu
        String startParam = findLoopStartParameter(loopNode, iteratorVar);
        if (startParam != null) {
            loopInfo.setStartParameter(startParam);
        }

        // Giá trị khởi tạo mặc định
        int startValue = determineStartValue(loopNode, iteratorVar);
        loopInfo.setStartValue(startValue);

        // Xác định phương thức cập nhật (step)
        int stepValue = determineStepValue(loopNode);
        loopInfo.setStepValue(stepValue);

        // Xác định giá trị kết thúc dựa trên condition
        int endValue = determineEndValue(condition);
        loopInfo.setEndValue(endValue);

        // Tính số lần lặp tối đa (giả định)
        int maxIterations = calculateMaxIterations(startValue, endValue, stepValue); // Giá trị mặc định an toàn
        loopInfo.setMaxIterations(maxIterations);

        return loopInfo;
    }

    /**
     * Tìm tham số ảnh hưởng đến giá trị bắt đầu của vòng lặp
     */
    private String findLoopStartParameter(LoopConditionCfgNode loopNode, String iteratorVar) {
        if (loopNode instanceof ForConditionCfgNode) {
            // Tìm nút khởi tạo của vòng lặp for
            for (ICfgNode n : method.getAllStatements()) {
                if (n instanceof ForInitializerCfgNode) {
                    Expression expr = ((ForInitializerCfgNode) n).getInitializerExpression();
                    if (expr instanceof VariableDeclarationExpression) {
                        VariableDeclarationExpression varDeclExpr = (VariableDeclarationExpression) expr;
                        for (Object fragment : varDeclExpr.fragments()) {
                            if (fragment instanceof VariableDeclarationFragment) {
                                VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                                if (varFragment.getName().getIdentifier().equals(iteratorVar)) {
                                    Expression initializer = varFragment.getInitializer();
                                    if (initializer instanceof SimpleName) {
                                        // Nếu khởi tạo là một biến (như i = a)
                                        String paramName = ((SimpleName) initializer).getIdentifier();
                                        // Kiểm tra xem có phải tham số không
                                        for (Object param : method.getParameters()) {
                                            SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
                                            if (parameter.getName().getIdentifier().equals(paramName)) {
                                                return paramName;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    //Thêm mới
    private void findMethodParameterInfluencingLoop(LoopInfo loopInfo, Expression condition) {
        if (condition instanceof InfixExpression) {
            InfixExpression infixExpr = (InfixExpression) condition;
            Expression rightOp = infixExpr.getRightOperand();
            
            if (rightOp instanceof SimpleName) {
                SimpleName rightName = (SimpleName) rightOp;
                String rightVarName = rightName.getIdentifier();
                
                // Kiểm tra xem đây có phải tham số của phương thức không
                for (Object param : method.getParameters()) {
                    SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
                    if (parameter.getName().getIdentifier().equals(rightVarName)) {
                        loopInfo.setLoopParameter(rightVarName);
                        return;
                    }
                }
            }
        }
    }
    //Thêm mới



    /**
     * Trích xuất tên biến lặp từ điều kiện vòng lặp
     */
    private String extractIteratorVariable(Expression condition) {
        if (condition instanceof InfixExpression) {
            InfixExpression infixExpr = (InfixExpression) condition;
            Expression leftOp = infixExpr.getLeftOperand();
            
            if (leftOp instanceof SimpleName) {
                return ((SimpleName) leftOp).getIdentifier();
            }
        }
        return null;
    }
    
    /**
     * Xác định giá trị khởi tạo của vòng lặp
     */
    private int determineStartValue(LoopConditionCfgNode loopNode, String iteratorVar) {
        if (loopNode instanceof ForConditionCfgNode) {
            // Tìm nút khởi tạo của vòng lặp for
            for (ICfgNode n : method.getAllStatements()) {
                if (n instanceof ForInitializerCfgNode) {
                    Expression expr = ((ForInitializerCfgNode) n).getInitializerExpression();
                    if (expr instanceof VariableDeclarationExpression) {
                        VariableDeclarationExpression varDeclExpr = (VariableDeclarationExpression) expr;
                        for (Object fragment : varDeclExpr.fragments()) {
                            if (fragment instanceof VariableDeclarationFragment) {
                                VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                                if (varFragment.getName().getIdentifier().equals(iteratorVar)) {
                                    Expression initializer = varFragment.getInitializer();
                                    if (initializer instanceof NumberLiteral) {
                                        return Integer.parseInt(initializer.toString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (loopNode instanceof WhileConditionCfgNode || loopNode instanceof DoConditionCfgNode) {
            // Tìm khai báo biến trước vòng lặp while/do-while
            for (ICfgNode n : method.getAllStatements()) {
                if (n instanceof DeclarationStatementCfgNode) {
                    Statement stmt = ((DeclarationStatementCfgNode) n).getStatement();
                    if (stmt instanceof VariableDeclarationStatement) {
                        VariableDeclarationStatement varDeclStmt = (VariableDeclarationStatement) stmt;
                        for (Object fragment : varDeclStmt.fragments()) {
                            if (fragment instanceof VariableDeclarationFragment) {
                                VariableDeclarationFragment varFragment = (VariableDeclarationFragment) fragment;
                                if (varFragment.getName().getIdentifier().equals(iteratorVar)) {
                                    Expression initializer = varFragment.getInitializer();
                                    if (initializer instanceof NumberLiteral) {
                                        return Integer.parseInt(initializer.toString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return 1; // Giá trị mặc định
    }
    
    /**
     * Xác định độ tăng/giảm (step) của vòng lặp
     */
    private int determineStepValue(LoopConditionCfgNode loopNode) {
        if (loopNode instanceof ForConditionCfgNode) {
            for (ICfgNode n : method.getAllStatements()) {
                if (n instanceof ForUpdaterCfgNode) {
                    Expression updateExpr = ((ForUpdaterCfgNode) n).getExpression();
                    return extractStepValue(updateExpr);
                }
            }
        } else if (loopNode instanceof WhileConditionCfgNode || loopNode instanceof DoConditionCfgNode) {
            // For while and do-while loops, find update expression in the loop body
            String iteratorVar = extractIteratorVariable(loopNode.getLoopCondition());
            for (ICfgNode n : method.getAllStatements()) {
                if (n instanceof ExpressionStatementCfgNode) {
                    Statement stmt = ((ExpressionStatementCfgNode) n).getStatement();
                    if (stmt instanceof ExpressionStatement) {
                        Expression expr = ((ExpressionStatement) stmt).getExpression();

                        // Check if this expression is modifying our iterator variable
                        if (isModifyingVariable(expr, iteratorVar)) {
                            return extractStepValue(expr);
                        }
                    }
                }
            }
        }

        return 1; // Default value
    }

    private boolean isModifyingVariable(Expression expr, String varName) {
        if (expr instanceof PostfixExpression) {
            PostfixExpression postfixExpr = (PostfixExpression) expr;
            return postfixExpr.getOperand().toString().equals(varName);
        } else if (expr instanceof PrefixExpression) {
            PrefixExpression prefixExpr = (PrefixExpression) expr;
            return prefixExpr.getOperand().toString().equals(varName);
        } else if (expr instanceof Assignment) {
            Assignment assignment = (Assignment) expr;
            return assignment.getLeftHandSide().toString().equals(varName);
        }
        return false;
    }

    private int extractStepValue(Expression expr) {
        if (expr instanceof PostfixExpression) {
            PostfixExpression postfixExpr = (PostfixExpression) expr;
            if (postfixExpr.getOperator() == PostfixExpression.Operator.INCREMENT) {
                return 1;
            } else if (postfixExpr.getOperator() == PostfixExpression.Operator.DECREMENT) {
                return -1;
            }
        } else if (expr instanceof PrefixExpression) {
            PrefixExpression prefixExpr = (PrefixExpression) expr;
            if (prefixExpr.getOperator() == PrefixExpression.Operator.INCREMENT) {
                return 1;
            } else if (prefixExpr.getOperator() == PrefixExpression.Operator.DECREMENT) {
                return -1;
            }
        } else if (expr instanceof Assignment) {
            Assignment assignment = (Assignment) expr;
            Expression rightSide = assignment.getRightHandSide();

            if (rightSide instanceof NumberLiteral) {
                int value = Integer.parseInt(rightSide.toString());

                if (assignment.getOperator() == Assignment.Operator.ASSIGN) {
                    // For direct assignment like i = 5, we need to compare with previous value
                    // But as a simple approximation, we assume increment by 1
                    return 1;
                } else if (assignment.getOperator() == Assignment.Operator.PLUS_ASSIGN) {
                    return value;
                } else if (assignment.getOperator() == Assignment.Operator.MINUS_ASSIGN) {
                    return -value;
                }
            } else if (rightSide instanceof InfixExpression) {
                InfixExpression infixExpr = (InfixExpression) rightSide;
                Expression leftOp = infixExpr.getLeftOperand();
                Expression rightOp = infixExpr.getRightOperand();

                // Handle i = i + 1 pattern
                if (assignment.getOperator() == Assignment.Operator.ASSIGN &&
                        leftOp.toString().equals(assignment.getLeftHandSide().toString()) &&
                        rightOp instanceof NumberLiteral) {

                    int value = Integer.parseInt(rightOp.toString());

                    if (infixExpr.getOperator() == InfixExpression.Operator.PLUS) {
                        return value;
                    } else if (infixExpr.getOperator() == InfixExpression.Operator.MINUS) {
                        return -value;
                    }
                }

                // Handle i = i * 2 or other non-linear updates (approximate)
                if (rightOp instanceof NumberLiteral) {
                    try {
                        return Integer.parseInt(rightOp.toString());
                    } catch (NumberFormatException e) {
                        return 1;
                    }
                }
            }
        }

        return 1; // Default step value
    }
    /**
     * Xác định giá trị kết thúc từ điều kiện vòng lặp
     */
    private int determineEndValue(Expression condition) {
        if (condition instanceof InfixExpression) {
            InfixExpression infixExpr = (InfixExpression) condition;
            Expression rightOp = infixExpr.getRightOperand();
            InfixExpression.Operator operator = infixExpr.getOperator();
            
            if (rightOp instanceof NumberLiteral) {
                int endValue = Integer.parseInt(rightOp.toString());
                
                if (operator == InfixExpression.Operator.LESS) {
                    return endValue - 1;
                } else if (operator == InfixExpression.Operator.LESS_EQUALS) {
                    return endValue;
                } else if (operator == InfixExpression.Operator.GREATER) {
                    return endValue + 1;
                } else if (operator == InfixExpression.Operator.GREATER_EQUALS) {
                    return endValue;
                }
                return endValue;
            } else if (rightOp instanceof SimpleName) {
                // Đây có thể là một biến, cần tìm giá trị của biến
                String varName = ((SimpleName) rightOp).getIdentifier();
                
                // Tìm giá trị của tham số từ các testcase đã có
                for (List<Variable> testcase : method.getAllTestcases()) {
                    for (Variable var : testcase) {
                        if (var.getName().equals(varName)) {
                            try {
                                return Integer.parseInt(var.getValue());
                            } catch (NumberFormatException e) {
                                // Không phải số nguyên
                            }
                        }
                    }
                }
            }
        }
        
        return 10; // Giá trị mặc định
    }
    
    /**
     * Tạo các testcase để phủ các boundary value cho vòng lặp
     */
    public List<List<Variable>> generateLoopBoundaryTestCases() {
        List<List<Variable>> testcases = new ArrayList<>();
        
        for (LoopInfo loopInfo : detectedLoops) {
            // Tạo testcase cho giá trị dưới giới hạn (0 lần lặp)
            testcases.add(createTestCaseForLoopIterations(loopInfo, loopInfo.getStartValue() - 1));
            
            // Tạo testcase cho giá trị tại giới hạn (1 lần lặp)
            testcases.add(createTestCaseForLoopIterations(loopInfo, loopInfo.getStartValue()));
            
            // Tạo testcase cho giá trị trong giới hạn (m lần lặp, với m ngẫu nhiên)
            int m = new Random().nextInt(loopInfo.getMaxIterations() - 2) + 1;
            int n_m = loopInfo.getStartValue() + m * loopInfo.getStepValue();
            testcases.add(createTestCaseForLoopIterations(loopInfo, n_m));
            
            // Tạo testcase cho giá trị sát giới hạn (max-1 lần lặp)
            int n_minus = loopInfo.getEndValue() - loopInfo.getStepValue();
            testcases.add(createTestCaseForLoopIterations(loopInfo, n_minus));
            
            // Tạo testcase cho giá trị tại giới hạn max (max lần lặp)
            testcases.add(createTestCaseForLoopIterations(loopInfo, loopInfo.getEndValue()));
            
            // Tạo testcase cho giá trị trên giới hạn (max+1 lần lặp)
            int n_plus = loopInfo.getEndValue() + loopInfo.getStepValue();
            testcases.add(createTestCaseForLoopIterations(loopInfo, n_plus));
        }
        
        return testcases;
    }

    /**
     * Tạo testcase để đạt được n lần lặp
     */

     //Thêm mới
    /**
    * Tạo testcase để đạt được số lần lặp mong muốn
    */
    private List<Variable> createTestCaseForLoopIterations(LoopInfo loopInfo, int targetValue) {
        List<Variable> testcase = new ArrayList<>();
        
        // Duyệt qua tất cả các tham số của phương thức
        for (Object param : method.getParameters()) {
            SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
            String paramName = parameter.getName().getIdentifier();
            
            // Trường hợp 1: Nếu phát hiện tham số ảnh hưởng đến vòng lặp
            if (loopInfo.getLoopParameter() != null && paramName.equals(loopInfo.getLoopParameter())) {
                // Với vòng lặp for (i=2; i <= x; i++), giá trị x cần >= i 
                if (loopInfo.getIteratorVariable() != null) {
                    // Trường hợp điều kiện dạng i <= x, với i tăng dần
                    if (targetValue >= loopInfo.getStartValue()) {
                        testcase.add(new Variable(paramName, parameter.getType().toString(), 
                                                String.valueOf(targetValue)));
                    }
                    // Trường hợp điều kiện dạng i >= x, với i giảm dần
                    else {
                        testcase.add(new Variable(paramName, parameter.getType().toString(), 
                                                String.valueOf(loopInfo.getStartValue() - 1)));
                    }
                } else {
                    testcase.add(new Variable(paramName, parameter.getType().toString(), 
                                            String.valueOf(targetValue)));
                }
            }
            // Trường hợp 2: Không có tham số được xác định rõ, gán trực tiếp cho tham số đầu tiên
            else if (loopInfo.getLoopParameter() == null && method.getParameters().size() == 1) {
                // Với factorial(int x), nếu điều kiện vòng lặp là i <= x
                if ("int".equals(parameter.getType().toString())) {
                    testcase.add(new Variable(paramName, parameter.getType().toString(), 
                                            String.valueOf(Math.max(targetValue, loopInfo.getStartValue()))));
                } else {
                    testcase.add(createRandomVariable(parameter));
                }
            }
            // Trường hợp 3: Các tham số khác không liên quan đến vòng lặp
            else {
//                testcase.add(new Variable(loopInfo.getLoopParameterName(), loopInfo.getLoopParameter(),
//                        String.valueOf(targetValue)));
                testcase.add(createRandomVariable(parameter));
            }
        }
        
        return testcase;
    }
     //Thêm mới

    // private List<Variable> createTestCaseForLoopIterations(LoopInfo loopInfo, int targetValue) {
    //     List<Variable> testcase = new ArrayList<>();

    //     // Duyệt qua tất cả các tham số của phương thức
    //     for (Object param : method.getParameters()) {
    //         SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
    //         String paramName = parameter.getName().toString();

    //         // Nếu là tham số ảnh hưởng đến điều kiện vòng lặp
    //         if (loopInfo.isParameterAffectingLoop(paramName)) {
    //             testcase.add(new Variable(paramName, parameter.getType().toString(), String.valueOf(targetValue)));
    //         } else {
    //             // Tạo giá trị ngẫu nhiên cho các tham số không ảnh hưởng
    //             testcase.add(createRandomVariable(parameter));
    //         }
    //     }

    //     return testcase;
    // }

    /**
     * Phân tích symbolic để xác định điều kiện chính xác cho testcase
     */

//     public List<List<Variable>> generateSymbolicTestCases() {
//        List<List<Variable>> testcases = new ArrayList<>();
//
//        for (LoopInfo loopInfo : detectedLoops) {
//            // Xác định các giá trị quan trọng cho kiểm thử vòng lặp
//            int startVal = loopInfo.getStartValue();
//            int step = loopInfo.getStepValue();
//            int endVal = loopInfo.getEndValue();
//
//            // Giá trị đặc biệt để kiểm thử vòng lặp (0, 1, m, n, n-1, n+1)
//            int[] specialValues = {
//                startVal - step,       // Không chạy vòng lặp: x = 1 cho i=2; i<=x; i++
//                startVal + 0,              // Chạy đúng 1 lần: x = 2
//                startVal + step,       // Chạy đúng 2 lần: x = 3
//                    endVal,   // Chạy nhiều lần: x = 7
//                    endVal - step,// Chạy nhiều lần hơn: x = 12
//                    endVal + step
//            };
//
//            // Tạo testcase cho mỗi giá trị
//            for (int value : specialValues) {
//                List<Variable> testcase = createTestCaseForLoopIterations(loopInfo, value);
//
//                // Kiểm tra tính hợp lệ và loại bỏ trùng lặp
//                if (testcase != null && !testcase.isEmpty() && !containsDuplicate(testcases, testcase)) {
//                    testcases.add(testcase);
//
//                    // Debug
//                    System.out.println("Tạo test case với giá trị: " + value + " -> " + testcase);
//                }
//            }
//        }
//
//        return testcases;
//    }
    public List<List<Variable>> generateSymbolicTestCases() {
        List<List<Variable>> testcases = new ArrayList<>();

        for (LoopInfo loopInfo : detectedLoops) {
            // Map để lưu trữ test case theo mục đích
            Map<String, List<Variable>> testCaseMap = new LinkedHashMap<>();

            // Xác định tham số ảnh hưởng đến vòng lặp
            String endParam = loopInfo.getLoopParameter();
            String startParam = loopInfo.getStartParameter();

            // Đây là vòng lặp phụ thuộc vào cả hai tham số (for i=a to i<b)
            if (startParam != null && endParam != null) {
                // 1. 0 iterations - điều kiện a >= b
                testCaseMap.put("0_iterations", createDualParamTestCase(loopInfo, 5, 5));   // a=5, b=5 => 0 lần lặp (i=5; 5<5; i++)

                // 2. 1 iteration - điều kiện a+1 = b
                testCaseMap.put("1_iteration", createDualParamTestCase(loopInfo, 4, 5));    // a=4, b=5 => 1 lần lặp

                // 3. m iterations (m = 3) - điều kiện b = a+3
                testCaseMap.put("m_iterations", createDualParamTestCase(loopInfo, 2, 5));   // a=2, b=5 => 3 lần lặp

                // 4. n-1 iterations (n=5) - điều kiện b = a+4
                testCaseMap.put("n-1_iterations", createDualParamTestCase(loopInfo, 1, 5)); // a=1, b=5 => 4 lần lặp

                // 5. n iterations (n=5) - điều kiện b = a+5
                testCaseMap.put("n_iterations", createDualParamTestCase(loopInfo, 0, 5));   // a=0, b=5 => 5 lần lặp

                // 6. n+1 iterations - điều kiện b = a+6
                testCaseMap.put("n+1_iterations", createDualParamTestCase(loopInfo, 0, 6)); // a=0, b=6 => 6 lần lặp
            }
            else if (endParam != null) {
                // Vòng lặp chỉ phụ thuộc vào tham số kết thúc
                int start = loopInfo.getStartValue();
                int step = loopInfo.getStepValue();

                // 1. 0 iterations - b <= start
                testCaseMap.put("0_iterations", createParameterBasedTestCase(loopInfo, start));

                // 2. 1 iteration - b = start+1
                testCaseMap.put("1_iteration", createParameterBasedTestCase(loopInfo, start + 1));

                // 3. m iterations (m = 3) - b = start+3
                testCaseMap.put("m_iterations", createParameterBasedTestCase(loopInfo, start + 3));

                // 4. n-1 iterations (n=5) - b = start+4
                testCaseMap.put("n-1_iterations", createParameterBasedTestCase(loopInfo, start + 4));

                // 5. n iterations (n=5) - b = start+5
                testCaseMap.put("n_iterations", createParameterBasedTestCase(loopInfo, start + 5));

                // 6. n+1 iterations - b = start+6
                testCaseMap.put("n+1_iterations", createParameterBasedTestCase(loopInfo, start + 6));
            }
            else {
                // Vòng lặp không phụ thuộc vào tham số, sử dụng cách cũ
                int startVal = loopInfo.getStartValue();
                int step = loopInfo.getStepValue();
                int endVal = loopInfo.getEndValue();

                int m = 3;  // Số lần lặp trung bình
                int n = 5;  // Số lần lặp tối đa giả định

                // 1. 0 iterations
                testCaseMap.put("0_iterations", createDefaultTestCase(startVal, startVal));

                // 2. Exactly 1 iteration
                testCaseMap.put("1_iteration", createDefaultTestCase(startVal, startVal + step));

                // 3. m iterations (m < n)
                testCaseMap.put("m_iterations", createDefaultTestCase(startVal, startVal + m * step));

                // 4. n-1 iterations
                testCaseMap.put("n-1_iterations", createDefaultTestCase(startVal, startVal + (n-1) * step));

                // 5. n iterations
                testCaseMap.put("n_iterations", createDefaultTestCase(startVal, startVal + n * step));

                // 6. n+1 iterations
                testCaseMap.put("n+1_iterations", createDefaultTestCase(startVal, startVal + (n+1) * step));
            }

            // Thêm vào danh sách kết quả
            for (Map.Entry<String, List<Variable>> entry : testCaseMap.entrySet()) {
                String purpose = entry.getKey();
                List<Variable> testcase = entry.getValue();

                // Chỉ thêm test case hợp lệ và không trùng lặp
                if (testcase != null && !testcase.isEmpty() && !containsDuplicate(testcases, testcase)) {
                    // Thêm metadata vào biến đầu tiên
                    Variable firstVar = testcase.get(0);
                    firstVar.setMetadata("purpose", purpose);

                    // Set số lần lặp mong đợi dựa theo purpose
                    switch (purpose) {
                        case "0_iterations":
                            firstVar.setMetadata("expectedIterations", "0");
                            break;
                        case "1_iteration":
                            firstVar.setMetadata("expectedIterations", "1");
                            break;
                        case "m_iterations":
                            firstVar.setMetadata("expectedIterations", "3");
                            break;
                        case "n-1_iterations":
                            firstVar.setMetadata("expectedIterations", "4");
                            break;
                        case "n_iterations":
                            firstVar.setMetadata("expectedIterations", "5");
                            break;
                        case "n+1_iterations":
                            firstVar.setMetadata("expectedIterations", "6");
                            break;
                    }

                    testcases.add(testcase);
                }
            }
        }

        return testcases;
    }
    /**
     * Tạo test case cho vòng lặp phụ thuộc vào hai tham số (vd: for i=a; i<b; i++)
     */
    private List<Variable> createDualParamTestCase(LoopInfo loopInfo, int startValue, int endValue) {
        List<Variable> testcase = new ArrayList<>();

        String startParam = loopInfo.getStartParameter();
        String endParam = loopInfo.getLoopParameter();

        // Duyệt qua tất cả các tham số của phương thức
        for (Object param : method.getParameters()) {
            SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
            String paramName = parameter.getName().getIdentifier();

            if (paramName.equals(startParam)) {
                // Tham số ảnh hưởng đến giá trị bắt đầu
                testcase.add(new Variable(paramName, parameter.getType().toString(), String.valueOf(startValue)));
            }
            else if (paramName.equals(endParam)) {
                // Tham số ảnh hưởng đến giá trị kết thúc
                testcase.add(new Variable(paramName, parameter.getType().toString(), String.valueOf(endValue)));
            }
            else {
                // Các tham số khác không liên quan đến vòng lặp
                testcase.add(createRandomVariable(parameter));
            }
        }

        return testcase;
    }

    /**
     * Tạo test case mặc định với giá trị cố định
     */
    private List<Variable> createDefaultTestCase(int startValue, int endValue) {
        List<Variable> testcase = new ArrayList<>();

        // Duyệt qua tất cả các tham số và gán giá trị tương ứng
        for (Object param : method.getParameters()) {
            SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
            testcase.add(createRandomVariable(parameter));
        }

        return testcase;
    }

    /**
     * Tính số lần lặp tối đa dựa trên giá trị bắt đầu, kết thúc và bước nhảy
     */
    private int calculateMaxIterations(int start, int end, int step) {
        if (step == 0) return 0;  // Tránh chia cho 0

        if ((step > 0 && start > end) || (step < 0 && start < end)) {
            return 0;  // Vòng lặp không thực thi
        }

        return Math.abs((end - start) / step) + 1;
    }

    /**
     * Tính giá trị target để đạt được số lần lặp mong muốn
     */
    private int calculateTargetValueForIterations(LoopInfo loopInfo, int iterations) {
        int startVal = loopInfo.getStartValue();
        int step = loopInfo.getStepValue();

        // Đối với vòng lặp for (i=start; i<=target; i+=step), target = start + (iterations-1)*step
        return startVal + (iterations - 1) * step;
    }

    /**
     * Tạo test case dựa trên tham số ảnh hưởng đến vòng lặp
     */
    private List<Variable> createParameterBasedTestCase(LoopInfo loopInfo, int targetValue) {
        List<Variable> testcase = new ArrayList<>();

        // Duyệt qua tất cả các tham số của phương thức
        for (Object param : method.getParameters()) {
            SingleVariableDeclaration parameter = (SingleVariableDeclaration) param;
            String paramName = parameter.getName().getIdentifier();

            // Trường hợp 1: Tham số ảnh hưởng trực tiếp đến vòng lặp
            if (loopInfo.getLoopParameter() != null && paramName.equals(loopInfo.getLoopParameter())) {
                // Đối với vòng lặp for (i=2; i<=x; i++), giá trị x cần = targetValue
                testcase.add(new Variable(paramName, parameter.getType().toString(), String.valueOf(targetValue)));
            }
            // Trường hợp 2: Không có tham số được xác định ảnh hưởng trực tiếp, sử dụng tham số đầu tiên
            else if (loopInfo.getLoopParameter() == null && method.getParameters().size() == 1) {
                testcase.add(new Variable(paramName, parameter.getType().toString(), String.valueOf(targetValue)));
            }
            // Trường hợp 3: Các tham số khác không liên quan đến vòng lặp
            else {
                testcase.add(createRandomVariable(parameter));
            }
        }

        return testcase;
    }


    private String formatTestCaseDesc(List<Variable> testcase) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < testcase.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(testcase.get(i).getName()).append("=").append(testcase.get(i).getValue());
        }
        sb.append("]");
        return sb.toString();
    }

    //Thêm mới
    /**
     * Kiểm tra xem testcase đã tồn tại trong danh sách hay chưa
     */
    // Kiểm tra trùng lặp
    private boolean containsDuplicate(List<List<Variable>> testcases, List<Variable> testcase) {
        for (List<Variable> existingTestcase : testcases) {
            boolean same = true;
            if (existingTestcase.size() != testcase.size()) continue;
            
            for (int i = 0; i < testcase.size(); i++) {
                if (!existingTestcase.get(i).getValue().equals(testcase.get(i).getValue())) {
                    same = false;
                    break;
                }
            }
            
            if (same) return true;
        }
        return false;
    }
    //Thêm mới


    /**
     * Tạo biến ngẫu nhiên cho các tham số không liên quan đến vòng lặp
     */
    private Variable createRandomVariable(SingleVariableDeclaration parameter) {
        Random random = new Random();
        String name = parameter.getName().toString();
        String type = parameter.getType().toString();
        String value;
        
        // Tạo giá trị phù hợp với kiểu
        switch (type) {
            case "int":
                value = String.valueOf(random.nextInt(20));
                break;
            case "double":
                value = String.valueOf(random.nextDouble() * 20);
                break;
            case "boolean":
                value = String.valueOf(random.nextBoolean());
                break;
            case "char":
                value = String.valueOf((char)(random.nextInt(26) + 'a'));
                break;
            case "String":
                value = generateRandomString();
                break;
            default:
                value = "0";
        }
        
        return new Variable(name, type, value);
    }

    private String generateRandomString() {
        String chars = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        int length = random.nextInt(10) + 1;
        
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        
        return sb.toString();
    }

    /**
     * Xây dựng biểu thức ràng buộc cho vòng lặp với giá trị mục tiêu
     */
    private Expression buildLoopConstraint(LoopInfo loopInfo, int targetValue) {
        // Tạo AST mới
        AST ast = AST.newAST(AST.JLS8);

        // Tạo biểu thức gán, ví dụ: x = 10
        Assignment assignment = ast.newAssignment();

        // Lấy biến ảnh hưởng đến vòng lặp (ví dụ: x)
        String loopVarName = loopInfo.getLoopParameterName();
        SimpleName leftName = ast.newSimpleName(loopVarName);

        // Tạo số nguyên cho giá trị mục tiêu
        NumberLiteral rightNumber = ast.newNumberLiteral(String.valueOf(targetValue));

        assignment.setLeftHandSide(leftName);
        assignment.setRightHandSide(rightNumber);
        assignment.setOperator(Assignment.Operator.ASSIGN);

        return assignment;
    }

    /**
     * Giải điều kiện ràng buộc bằng symbolic execution và constraint solver
     */
    private List<Variable> solveConstraint(Expression constraint) {
        try {
            // Tạo danh sách điều kiện với chỉ một điều kiện
            List<Expression> conditions = new ArrayList<>();
            conditions.add(constraint);

            // Sử dụng constraint solver để giải điều kiện
            String currentPath = System.getProperty("user.dir");
            ConstraintSolver solver = new ConstraintSolver(conditions, method.getParameters(), currentPath);
            List<Variable> result = solver.solveConditions();

            // Chuyển đổi kết quả sang định dạng testcase cần thiết
            List<Variable> testcase = new ArrayList<>();
            for (Object parameter : method.getParameters()) {
                for (Variable variable : result) {
                    if (((SingleVariableDeclaration) parameter).getName().toString().equals(variable.getName())) {
                        variable.setType(((SingleVariableDeclaration) parameter).getType().toString());
                        testcase.add(variable);
                    }
                }
            }

            return testcase;
        } catch (Exception e) {
            System.err.println("Lỗi khi giải điều kiện ràng buộc: " + e.getMessage());
            return null;
        }
    }
}