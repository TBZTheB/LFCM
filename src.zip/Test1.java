public class Test1 {
    public   int i4_power(int i, int j) {
        int value;
        // Trường hợp khi j < 0
        if (j < 0) {
            if (i == 0) {
                return -1;  // 0 mũ số âm là không hợp lệ
            } else if (i == 1) {
                return 1;  // 1 mũ bất kỳ luôn là 1
            } else {
                return 0;  // Các số khác ngoài 0 và 1 mũ âm sẽ trả về 0
            }
        }
        // Trường hợp khi j == 0
        else if (j == 0) {
            return 1;  // Bất kỳ số nào mũ 0 đều là 1
        }
        // Trường hợp khi j > 0
        else {
            value = 1;
            for (int k = 1; k <= j; k++) {
                value *= i;  // Tính toán mũ i^j
            }
        }

        return value;
    }
}
