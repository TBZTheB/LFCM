package solvingConditions;

import java.util.HashMap;
import java.util.Map;

public class Variable {
    private String type;
    private String name;
    private String value;

    public Variable(String name, String type) {
        this.type = type;
        this.name = name;
        this.value = null;
    }

//    public Variable(String name, String type, String value) {
//        this.type = type;
//        this.name = name;
//        this.value = value;
//    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "{" +
                "type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", value='" + value + '\'' +
                '}';
    }

    private Map<String, String> metadata;

    public Variable(String name, String type, String value) {
        this.name = name;
        this.type = type;
        this.value = value;
        this.metadata = new HashMap<>();
    }

    public void setMetadata(String key, String value) {
        if (metadata == null) {
            metadata = new HashMap<>();
        }
        metadata.put(key, value);
    }

    public String getMetadata(String key) {
        if (metadata == null) {
            return null;
        }
        return metadata.get(key);
    }

    public Map<String, String> getAllMetadata() {
        return metadata != null ? metadata : new HashMap<>();
    }
}
