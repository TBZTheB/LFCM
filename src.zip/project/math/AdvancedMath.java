package project.math;

public class AdvancedMath {
    
    // Tính tổng các chữ số của một số nguyên
    public static int sumOfDigits(int num) {
        int sum = 0;
        // Xử lý số âm
        num = Math.abs(num);
        
        while (num > 0) {
            sum += num % 10;
            num /= 10;
        }
        return sum;
    }
    

    
    // Tính ước chung lớn nhất của ba số
    public static int gcdOfThree(int a, int b, int c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            return -1;

        }
        else {

            // Tính GCD của a và b trước
            int gcd = gcd(a, b);

            // Sau đó tính GCD của kết quả và c
            return gcd(gcd, c);
        }
    }
    
    // Hàm trợ giúp tính GCD của hai số
    private static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    
    // Tính số Armstrong (số mà tổng lũy thừa các chữ số bằng chính nó)
    public static int isArmstrong(int num) {
        if (num < 0) return -1;
        
        int original = num;
        int sum = 0;
        int digits = countDigits(num);
        
        while (num > 0) {
            int digit = num % 10;
            sum += power(digit, digits);
            num /= 10;
        }
        
        return (sum == original) ? 1 : 0;
    }
    
    // Đếm số chữ số
    private static int countDigits(int num) {
        if (num == 0) return 1;
        
        int count = 0;
        while (num != 0) {
            count++;
            num /= 10;
        }
        return count;
    }
    
    // Lũy thừa
    private static int power(int base, int exponent) {
        if (exponent == 0) return 1;
        
        int result = 1;
        for (int i = 1; i <= exponent; i++) {
            result *= base;
        }
        return result;
    }
    
    // Tìm số lớn thứ hai trong ba số
    public static int secondLargest(int a, int b, int c) {
        if (a >= b && a >= c) {
            // a là lớn nhất
            return (b >= c) ? b : c;
        } else if (b >= a && b >= c) {
            // b là lớn nhất
            return (a >= c) ? a : c;
        } else {
            // c là lớn nhất
            return (a >= b) ? a : b;
        }
    }
}