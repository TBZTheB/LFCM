package project.math;

public class BasicMath {
    // Factorial function
    public    int factorial(int n) {
        if (n < 0) return -1; // Error for negative input
        if (n <= 1) return 1;
        
        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
    
    // GCD function
    public    int gcd(int a, int b) {
        if (a <= 0 || b <= 0) return -1;
        
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    
    // Power function
    public    int power(int base, int exponent) {
        if (exponent < 0) return -1;
        if (exponent == 0) return 1;
        
        int result = 1;
        for (int i = 1; i <= exponent; i++) {
            result *= base;
        }
        return result;
    }
    
    // Fibonacci function
    public    int fibonacci(int n) {
        if (n < 0) return -1;
        if (n <= 1) return n;
        
        int a = 0, b = 1;
        for (int i = 2; i <= n; i++) {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    }
    
    // Sum of natural numbers
    public    int sumOfNaturals(int n) {
        if (n < 0) return -1;
        
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}