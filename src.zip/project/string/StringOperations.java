package project.string;

public class StringOperations {
    
    // Đếm số chữ số trong một chuỗi
    public static int countDigits(String str) {
        if (str == null) return -1;
        
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))) {
                count++;
            }
        }
        return count;
    }
    
    // Đếm số nguyên âm trong một chuỗi (a, e, i, o, u)
    public static int countVowels(String str) {
        if (str == null) return -1;
        
        int count = 0;
        str = str.toLowerCase();
        
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        return count;
    }
    
    // Kiểm tra chuỗi có phải là palindrome (đọc xuôi ngược như nhau)
    public static int isPalindrome(String str) {
        if (str == null) return -1;
        
        str = str.toLowerCase();
        int left = 0;
        int right = str.length() - 1;
        
        while (left < right) {
            if (str.charAt(left) != str.charAt(right)) {
                return 0;
            }
            left++;
            right--;
        }
        return 1;
    }
    
    // Tính giá trị ASCII trung bình của các ký tự trong chuỗi
    public static int averageASCII(String str) {
        if (str == null || str.isEmpty()) return -1;
        
        int sum = 0;
        for (int i = 0; i < str.length(); i++) {
            sum += (int) str.charAt(i);
        }
        return sum / str.length();
    }
    

}