package string;

public class ConditionalLogic {
    
    // Phân loại điểm số
    public static char gradeScore(int score) {
        if (score < 0 || score > 100) {
            return 'X'; // Invalid score
        }
        
        if (score >= 90) {
            return 'A';
        } else if (score >= 80) {
            return 'B';
        } else if (score >= 70) {
            return 'C';
        } else if (score >= 60) {
            return 'D';
        } else {
            return 'F';
        }
    }
    
    // Tính giá vé dựa trên tuổi và khoảng cách
    public static int calculateTicketPrice(int age, int distance) {
        // Giá cơ bản
        int basePrice = 100;
        
        // Xử lý các giá trị không hợp lệ
        if (age < 0 || distance < 0) {
            return -1;
        }
        
        // Giảm giá theo tuổi
        if (age < 6) {
            basePrice = 0; // Miễn phí cho trẻ dưới 6 tuổi
        } else if (age < 12) {
            basePrice = basePrice / 2; // Giảm 50% cho trẻ từ 6-11
        } else if (age >= 65) {
            basePrice = basePrice * 7 / 10; // Giảm 30% cho người già từ 65 tuổi
        }
        
        // Phụ phí theo khoảng cách
        if (distance > 100) {
            basePrice += 50;
        } else if (distance > 50) {
            basePrice += 25;
        } else if (distance > 20) {
            basePrice += 10;
        }
        
        return basePrice;
    }
    
    // Phân loại tam giác dựa trên độ dài ba cạnh
    public static int triangleType(int a, int b, int c) {
        // Kiểm tra các cạnh phải dương
        if (a <= 0 || b <= 0 || c <= 0) {
            return -1;
        }
        
        // Kiểm tra điều kiện tam giác hợp lệ
        if (a + b <= c || a + c <= b || b + c <= a) {
            return 0; // Không phải tam giác
        }
        
        // Kiểm tra tam giác đều (ba cạnh bằng nhau)
        if (a == b && b == c) {
            return 1; // Tam giác đều
        }
        
        // Kiểm tra tam giác cân (có hai cạnh bằng nhau)
        if (a == b || b == c || a == c) {
            return 2; // Tam giác cân
        }
        
        // Kiểm tra tam giác vuông (áp dụng định lý Pytago)
        if (a*a + b*b == c*c || a*a + c*c == b*b || b*b + c*c == a*a) {
            return 3; // Tam giác vuông
        }
        
        return 4; // Tam giác thường
    }
    
    // Kiểm tra năm nhuận
    public static int isLeapYear(int year) {
        if (year < 0) {
            return -1; // Năm không hợp lệ
        }
        
        // Năm nhuận là năm chia hết cho 4
        // Ngoại trừ năm chia hết cho 100 mà không chia hết cho 400
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            return 1; // Năm nhuận
        }
        
        return 0; // Không phải năm nhuận
    }
    
    // Kiểm tra xem một số có phải là số hoàn hảo không
    // (số hoàn hảo là số có tổng các ước số của nó bằng chính nó)
    public static int isPerfectNumber(int num) {
        if (num <= 0) {
            return -1; // Số không hợp lệ
        }
        
        int sum = 0;
        
        // Tìm các ước số và tính tổng
        for (int i = 1; i < num; i++) {
            if (num % i == 0) {
                sum += i;
            }
        }
        
        // Kiểm tra tổng các ước có bằng số ban đầu không
        if (sum == num) {
            return 1; // Là số hoàn hảo
        }
        
        return 0; // Không phải số hoàn hảo
    }
    
    // Đánh giá điểm trung bình môn học
    public static char evaluateGPA(int math, int science, int english) {
        // Kiểm tra điểm hợp lệ
        if (math < 0 || math > 100 || science < 0 || science > 100 || english < 0 || english > 100) {
            return 'X'; // Điểm không hợp lệ
        }
        
        // Tính điểm trung bình
        int average = (math + science + english) / 3;
        
        // Các điều kiện đặc biệt
        if (math < 40 || science < 40 || english < 40) {
            return 'F'; // Trượt nếu bất kỳ môn nào dưới 40
        }
        
        // Xếp loại dựa trên điểm trung bình
        if (average >= 80) {
            return 'A';
        } else if (average >= 60) {
            return 'B';
        } else if (average >= 50) {
            return 'C';
        } else if (average >= 40) {
            return 'D';
        } else {
            return 'F';
        }
    }
}