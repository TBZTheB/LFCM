import cfg.generation.testpath.Check.FullTestpaths;
import cfg.nodes.*;
import cover.Cover;
import cover.CoverC1;
import cover.CoverC2;
import cover.CoverC3;
import org.eclipse.jdt.core.dom.*;
import solvingConditions.Variable;

import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.util.*;

public class Method {
    private List modifiers;
    private Type returnValueType;
    private SimpleName methodName;
    private List parameters;
    private StringBuilder contentmethod;
    private List<ICfgNode> allNodes;
    private FullTestpaths testpaths;
    private List<List<Variable>> testcases;
    private List<List<Variable>> allTestcases;
    private Cover coverC1;
    private Cover coverC2;
    private Cover coverC3;
    // Thêm thuộc tính
    private String filePath;

    public Method(SimpleName name, List modifiers, Type returnValueType,
                  List parameters, StringBuilder contentmethod, List<ICfgNode> allNodes, FullTestpaths testpaths, String filePath) {
        this.filePath = filePath;
        this.modifiers = modifiers;
        this.returnValueType = returnValueType;
        this.methodName = name;
        this.parameters = parameters;
        this.contentmethod = contentmethod;
        this.allNodes = allNodes;
        this.testpaths = testpaths;
        this.testcases = new ArrayList<>();
        this.allTestcases = new ArrayList<>();
        coverC1 = new CoverC1(allNodes);
        coverC2 = new CoverC2(allNodes);
        coverC3 = new CoverC3(allNodes);
    }


    public StringBuilder addStaticContentmethod(){
        StringBuilder content = new StringBuilder(contentmethod);
        int positionStatic = 0;
        boolean checkStatic = false;
        for (Object modifier : modifiers) {
            if (modifier.toString().equals("static")) {
                checkStatic = true;
                break;
            }
        }
        if(!checkStatic){
            if(!modifiers.isEmpty()){
                positionStatic += modifiers.get(0).toString().length();
            }
            content = content.replace(positionStatic, positionStatic, " static");
        }
        return content;
    }

    public List<Variable> randomTestcase(){
        List<Variable> testcase = new ArrayList<>();
//        System.out.println("Testcase random:");
        for (Object o : parameters) {
            SingleVariableDeclaration parameter = (SingleVariableDeclaration) o;
            Type type = parameter.getType();
            SimpleName name = parameter.getName();
            Random random = new Random();
            String var = null;
            // random các biến ban đầu < 20
            switch (type.toString()) {
                //số ngẫu nhin trong khoảng [0, 20)
                case "double":
                    var = String.valueOf(random.nextDouble() * 20);
//                    System.out.println("double " + name + " = " + var);
                    break;
                //số ngẫu nhin trong khoảng [0, 20)
                case "float":
                    var = String.valueOf(random.nextFloat() * 20);
//                    System.out.println("float " + name + " = " + var);
                    break;
                case "long":
                    var = String.valueOf(random.nextInt(20));
//                    System.out.println("long " + name + " = " + var);
                    break;
                case "int":
                    var = String.valueOf(random.nextInt(20));
//                    System.out.println("int " + name + " = " + var);
                    break;
                case "short":
                    var = String.valueOf(random.nextInt(20));
//                    System.out.println("short " + name + " = " + var);
                    break;
                case "byte":
                    var = String.valueOf(random.nextInt(20));
//                    System.out.println("byte " + name + " = " + var);
                    break;
                case "boolean":
                    var = String.valueOf(random.nextBoolean());
//                    System.out.println("boolean " + name + " = " + var);
                    break;
                // ký tự ngẫu nhiên trong ASCII trong phân vị 32 đến 126 bao gồm in thuờng và in hoa, số và k tự đặc biệt
                case "char":
                    var = String.valueOf((char) (random.nextInt(95) + 32));
//                    System.out.println("char " + name + " = " + var);
                    break;
                    // Ngẫu nhiên gồm chữ hoa và chữ thường và chữ số, độ dài tối đa 15 ký tự
                case "String":
                    String alpha = "abcdefghijklmnopqrstuvwxyz"; // a-z

                    String alphaUpperCase = alpha.toUpperCase(); // A-Z

                    String digits = "0123456789"; // 0-9

                    String ALPHA_NUMERIC = alpha + alphaUpperCase + digits;
                    StringBuilder sb = new StringBuilder();
                    int numberOfCharactor = random.nextInt(15);
                    for (int j = 0; j < numberOfCharactor; j++) {
                        int number = random.nextInt(ALPHA_NUMERIC.length());
                        char ch = ALPHA_NUMERIC.charAt(number);
                        sb.append(ch);
                    }
                    var = sb.toString();
//                    System.out.println("String " + name + " = " + var);
                    break;
            }
            if (var != null) {
                testcase.add(new Variable(name.toString(), type.toString(), var));
            }
        }
        return testcase;
    }

    public void readMarkV1(boolean checkC1, boolean checkC2, boolean checkC3) throws FileNotFoundException {
        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";

        List<String> pathMarks = new ArrayList<>();
        for(int i = 0; i < testcases.size(); i ++){
            pathMarks.add(currentPath + "JdtBase/src/result/marks/" + methodName + "Marks/TestDriverResult" + (allTestcases.size() + i + 1) + ".txt");
        }
//        System.out.println("File mark: " + pathMarks);
        if(!checkC1){
            coverC1.readMark(pathMarks);
            coverC1.getAllTestcases().addAll(testcases);
        }
        if (!checkC2){
            coverC2.readMark(pathMarks);
            coverC2.getAllTestcases().addAll(testcases);
        }
        if (!checkC3){
            coverC3.readMark(pathMarks);
            coverC3.getAllTestcases().addAll(testcases);
        }
        allTestcases.addAll(testcases);
//        System.out.println(testcases);
//        System.out.println("C1: " + coverC1.numberCovered() + "/" + coverC1.numberAllCovered());
//        System.out.println("C2: " + coverC2.numberCovered() + "/" + coverC2.numberAllCovered());
//        System.out.println("C3: " + coverC3.numberCovered() + "/" + coverC3.numberAllCovered());

        testcases = new ArrayList<>();
    }

    //Thêm mới
    public boolean hasLoop() {
        for (ICfgNode node : allNodes) {
            if (node instanceof LoopConditionCfgNode) {
                return true;
            }
        }
        return false;
    }

    public List<ICfgNode> getAllStatements() {
        // Giả sử `allNodes` chứa tất cả các câu lệnh trong phương thức, bao gồm cả các vòng lặp.
        return allNodes;
    }

    public void addTestcase(List<Variable> testcase) {
        this.testcases.add(testcase);
    }

    //Thêm mới

    public List getModifiers() {
        return modifiers;
    }

    public void setModifiers(List modifiers) {
        this.modifiers = modifiers;
    }

    public SimpleName getMethodName() {
        return methodName;
    }

    public void setMethodName(SimpleName methodName) {
        this.methodName = methodName;
    }

    public List getParameters() {
        return parameters;
    }

    public void setParameters(List parameters) {
        this.parameters = parameters;
    }

    public List<List<Variable>> getTestcases() {
        return testcases;
    }


    public FullTestpaths getTestpaths() {
        return testpaths;
    }

    public void setTestpaths(FullTestpaths testpaths) {
        this.testpaths = testpaths;
    }

    public List<List<Variable>> getAllTestcases() {
        return allTestcases;
    }


    public Cover getCoverC1() {
        return coverC1;
    }

    public void setCoverC1(Cover coverC1) {
        this.coverC1 = coverC1;
    }

    public Cover getCoverC2() {
        return coverC2;
    }

    public void setCoverC2(Cover coverC2) {
        this.coverC2 = coverC2;
    }

    public Cover getCoverC3() {
        return coverC3;
    }

    public void setCoverC3(Cover coverC3) {
        this.coverC3 = coverC3;
    }
    // Thêm getter và setter
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

}

