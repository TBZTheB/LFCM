import java.io.IOException;
import java.nio.file.Paths;

public class ISMMain {
    public static void main(String[] args) throws IOException {
        // Get current path and configure folder path for scanning
        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";
        
        // Path to the folder containing test files
        String folderPath = currentPath + "JdtBase/src/ProjectTest/MathematicalAlgorithms/";
        System.out.println("Scanning folder: " + folderPath);
        
        // Create ISM instance and generate test cases with file coverage metrics
        ISM ism = new ISM(folderPath);
        ism.generateTestcase();
        
        System.out.println("\nTest generation and file coverage analysis completed.");
        System.out.println("Check the result folder for detailed reports.");
    }
}