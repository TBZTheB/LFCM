import cfg.generation.testpath.Check.FullTestpaths;
import cfg.nodes.*;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import solvingConditions.ConstraintSolver;
import solvingConditions.Variable;
import symbolicExecution.SymbolicExecutionTestpath;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.*;

public class LFCm {
    String filePath;
    public LFCm(String filePath) {
        this.filePath = filePath;
    }

    public void generateTestcase () throws IOException {
        String currentPath = Paths.get("").toAbsolutePath().toString();
        currentPath = currentPath.replace("\\", "/") + "/";

        double startTime = System.currentTimeMillis();
        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        double memoryBefore = runtime.totalMemory() - runtime.freeMemory();

        TestDriver testDriver = new TestDriverISM(filePath);
        testDriver.doTestDriver();
        testDriver.compileTestDriver();


        List<Method> methodList = testDriver.getMethods();
        JSONObject jsonObject = new JSONObject();
        for (Method method : methodList){
            JSONArray jsonMethod = new JSONArray();
            List<Variable> testcaseRandom = method.randomTestcase();
            method.getTestcases().add(testcaseRandom);
            String filepathMark = currentPath + "JdtBase/src/result/marks/" + method.getMethodName() + "Marks/TestDriverResult"
                    + (method.getAllTestcases().size() + method.getTestcases().size()) + ".txt";
            jsonMethod.add(ISM.addTestcaseJsonMethod(testcaseRandom, filepathMark));
            jsonObject.put(method.getMethodName(), jsonMethod);
            ISM.writeFileJson(currentPath + "JdtBase/src/result/Testcases.json", jsonObject);
            testDriver.runTestDriver();
            method.readMarkV1(false, false, false);

            boolean check = true;
            while (check){
                check = false;
                boolean checkC1 = true;
                boolean checkC2 = true;
                boolean checkC3 = true;
                jsonObject = new JSONObject();
                jsonMethod = new JSONArray();
                FullTestpaths testpaths = method.getTestpaths();
                while (!testpaths.isEmpty()) {
                    List<ICfgNode> testpath = testpaths.get(0).getAllCfgNodes();
                    checkC1 = method.getCoverC1().checkCoveredTestpath(testpath);
                    checkC2 = method.getCoverC2().checkCoveredTestpath(testpath);
                    checkC3 = method.getCoverC3().checkCoveredTestpath(testpath);
                    if(!checkC1 || !checkC2 || !checkC3){
                        String currentPath1 = Paths.get("").toAbsolutePath().toString();
                        SymbolicExecutionTestpath sym = new SymbolicExecutionTestpath(testpaths.get(0).getAllCfgNodes(), method.getParameters());
                        List<Expression> conditions = sym.symbolicExecution();
                        if(!conditions.isEmpty() && !conditions.get(0).toString().equals("false")){
                            ConstraintSolver constraintSolver = new ConstraintSolver(conditions, method.getParameters(), currentPath1);
                            List<Variable> result = constraintSolver.solveConditions();
                            List<Variable> testcase = new ArrayList<>();
                            for(Object parameter: method.getParameters()){
                                for(Variable variable : result){
                                    if(((SingleVariableDeclaration) parameter).getName().toString().equals(variable.getName())){
                                        variable.setType(((SingleVariableDeclaration) parameter).getType().toString());
                                        testcase.add(variable);
                                    }
                                }
                            }

                            if(!testcase.isEmpty()){
                                method.getTestcases().add(testcase);
                                filepathMark = currentPath + "JdtBase/src/result/marks/" + method.getMethodName() + "Marks/TestDriverResult"
                                        + (method.getAllTestcases().size() + method.getTestcases().size()) + ".txt";
                                jsonMethod.add(ISM.addTestcaseJsonMethod(testcase, filepathMark));
                                jsonObject.put(method.getMethodName(), jsonMethod);

                                check = true;
                                testpaths.remove(0);
                                break;
                            }
                        }
                    }
                    testpaths.remove(0);
                }

                if(check){
                    ISM.writeFileJson(currentPath + "JdtBase/src/result/Testcases.json", jsonObject);
                    //                System.out.println("\nTest driver " + count);
                    testDriver.runTestDriver();
                    method.readMarkV1(checkC1, checkC2, checkC3);
                }
            }

            DecimalFormat decimalFormat = new DecimalFormat( "#.##" );
            System.out.println("Unit test: " + method.getMethodName());
            System.out.println("Testcase: " + method.getParameters());
            System.out.println("All testcase of C1: " + method.getCoverC1().getAllTestcasesString());
            System.out.println("Covered C1: " + decimalFormat.format((double)method.getCoverC1().numberCovered() / method.getCoverC1().numberAllCovered() * 100) + "%");
            System.out.println("All testcase of C2: " + method.getCoverC2().getAllTestcasesString());
            System.out.println("Covered C2: " + decimalFormat.format((double)method.getCoverC2().numberCovered() / method.getCoverC2().numberAllCovered() * 100) + "%");
            System.out.println("All testcase of C3: " + method.getCoverC3().getAllTestcasesString());
            System.out.println("Covered C3: " + decimalFormat.format((double)method.getCoverC3().numberCovered() / method.getCoverC3().numberAllCovered() * 100) + "%");
            System.out.println();

//            Thêm mới
                if (method.hasLoop()) {
                    analyzeLoop(method); // Phân tích vòng lặp
                }
            testDriver.compileTestDriver();
            testDriver.runTestDriver();

            //Thêm mới

            double endTime = System.currentTimeMillis(); // Kết thúc đo thời gian
            double duration = (endTime - startTime); // Tính thời gian chạy
            System.out.println("Run: " + duration + " milliseconds");
            double memoryAfter = runtime.totalMemory() - runtime.freeMemory(); // Bộ nhớ sau khi chạy
            double memoryUsed = memoryAfter - memoryBefore; // Bộ nhớ đã sử dụng
            System.out.println("Used memory: " + decimalFormat.format(memoryUsed / 1048576) + "MB");
        }

        // Tạo Map để nhóm các phương thức theo tệp nguồn
        Map<String, List<Method>> methodsByFile = new HashMap<>();

        for (Method method2 : methodList) {
            // Lấy đường dẫn tệp từ tên phương thức hoặc metadata khác
            String filePath = extractFilePathFromMethod(method2); // Cần viết hàm này

            if (!methodsByFile.containsKey(filePath)) {
                methodsByFile.put(filePath, new ArrayList<>());
            }
            methodsByFile.get(filePath).add(method2);
        }

        // Tính toán và hiển thị độ phủ tệp cho mỗi tệp
        System.out.println("\n===== FILE COVERAGE SUMMARY =====");
        for (Map.Entry<String, List<Method>> entry : methodsByFile.entrySet()) {
            String filePath = entry.getKey();
            List<Method> methods = entry.getValue();

            FileCoverage fileCoverage = new FileCoverage(filePath, methods);
            System.out.println(fileCoverage.generateCoverageReport());

            // Lưu kết quả độ phủ tệp vào file JSON
            writeFileJson(currentPath + "JdtBase/src/result/FileCoverage_" + getFileNameFromPath(filePath) + ".json",
                    fileCoverage.toJSON());
        }
        // Tạo báo cáo tổng hợp cho toàn bộ dự án
        generateProjectCoverageReport(methodsByFile);

    }

    // Thay thế phương thức analyzeLoop trong ISMv0.java
    private void analyzeLoop(Method method) throws IOException {
        System.out.println("\n===== ANALYZING LOOPS USING SYMBOLIC EXECUTION =====");

        // Sử dụng LoopAnalyzer để phát hiện và phân tích vòng lặp
        LoopAnalyzer loopAnalyzer = new LoopAnalyzer(method);
        List<LoopInfo> loops = loopAnalyzer.detectLoops();

        if (loops.isEmpty()) {
            System.out.println("No loops detected in method " + method.getMethodName());
            return;
        }

        System.out.println("Detected " + loops.size() + " loops in method " + method.getMethodName());

        // In thông tin chi tiết về vòng lặp
        for (int i = 0; i < loops.size(); i++) {
            LoopInfo loopInfo = loops.get(i);
            System.out.println("Loop #" + (i+1) + ": " + loopInfo);
            System.out.println("LOOP RANGE: [start_value, end_value, step_value]: [" +
                    loopInfo.getStartValue() + ", " + loopInfo.getEndValue() + ", " + loopInfo.getStepValue() + "]");

            String paramInfo = loopInfo.getLoopParameter() != null ?
                    " phụ thuộc vào tham số \"" + loopInfo.getLoopParameter() + "\"" : "";

            System.out.println("Trong phương thức \"" + method.getMethodName() +
                    "\" vòng lặp có biến \"" + loopInfo.getIteratorVariable() +
                    "\" chạy từ " + loopInfo.getStartValue() + paramInfo);

            System.out.println("Loop #" + (i+1) + ": " + formatLoopInfo(loopInfo));
        }

        // Các test case theo tiêu chuẩn độ phủ vòng lặp
        Map<String, List<List<Variable>>> categorizedTestcases = new LinkedHashMap<>();
        categorizedTestcases.put("0_iterations", new ArrayList<>());  // 0 lần lặp
        categorizedTestcases.put("1_iteration", new ArrayList<>());   // 1 lần lặp
        categorizedTestcases.put("m_iterations", new ArrayList<>());  // m lần lặp (m < N)
        categorizedTestcases.put("n-1_iterations", new ArrayList<>()); // N-1 lần lặp
        categorizedTestcases.put("n_iterations", new ArrayList<>());   // N lần lặp (tối đa)
        categorizedTestcases.put("n+1_iterations", new ArrayList<>());  // N+1 lần lặp

        // Sinh testcase dựa trên thực thi tượng trưng và giải ràng buộc
        List<List<Variable>> loopTestcases = loopAnalyzer.generateSymbolicTestCases();

        // Nếu không sinh được, sử dụng phương pháp boundary value
        if (loopTestcases.isEmpty()) {
            System.out.println("No symbolic testcases could be generated. Using boundary value analysis instead.");
            loopTestcases = loopAnalyzer.generateLoopBoundaryTestCases();
        }

        // Phân loại các test case đã sinh
        for (List<Variable> testcase : loopTestcases) {
            if (!testcase.isEmpty()) {
                String purpose = testcase.get(0).getMetadata("purpose");
                if (purpose != null) {
                    if (!categorizedTestcases.containsKey(purpose)) {
                        categorizedTestcases.put(purpose, new ArrayList<>());
                    }
                    categorizedTestcases.get(purpose).add(testcase);

                    // Thêm vào phương thức
                    method.addTestcase(testcase);

                    // Hiển thị thông tin
                    String iterations = testcase.get(0).getMetadata("expectedIterations");
                    String description = formatTestCaseDesc(testcase);
                    System.out.println("Generated test case for " + purpose + " → " + description);
                }
            }
        }

        // Validate the test cases
        validateLoopIterations(method, loops, loopTestcases);

        // Generate summary report
        System.out.println("\n===== LOOP TEST COVERAGE REPORT =====");
        int validTestcaseCount = 0;

        // Report for each category of test
        for (Map.Entry<String, List<List<Variable>>> entry : categorizedTestcases.entrySet()) {
            int count = entry.getValue().size();
            validTestcaseCount += count;
            System.out.println("- " + entry.getKey() + ": " + count + " test cases");
        }

        System.out.println("Total valid test cases: " + validTestcaseCount);

        // Check coverage of all required criteria
        Set<String> requiredCriteria = new HashSet<>(Arrays.asList(
                "0_iterations", "1_iteration", "n-1_iterations", "n_iterations"
        ));

        Set<String> missingCriteria = new HashSet<>(requiredCriteria);
        for (String key : categorizedTestcases.keySet()) {
            if (requiredCriteria.contains(key) && !categorizedTestcases.get(key).isEmpty()) {
                missingCriteria.remove(key);
            }
        }

        if (!missingCriteria.isEmpty()) {
            System.out.println("\nWARNING: Some loop testing criteria are not covered:");
            for (String missingCriterion : missingCriteria) {
                System.out.println("- " + missingCriterion);
            }
        } else {
            System.out.println("\nAll required loop testing criteria are covered.");
        }

        // Save testcases to JSON file
        JSONArray jsonTestcases = new JSONArray();
        for (List<Variable> testcase : loopTestcases) {
            if (!testcase.isEmpty()) {
                JSONObject jsonTestcase = new JSONObject();
                JSONArray jsonVariables = new JSONArray();

                // Add metadata
                if (testcase.get(0).getMetadata("purpose") != null) {
                    jsonTestcase.put("purpose", testcase.get(0).getMetadata("purpose"));
                }
                if (testcase.get(0).getMetadata("expectedIterations") != null) {
                    jsonTestcase.put("expectedIterations", testcase.get(0).getMetadata("expectedIterations"));
                }

                // Add variables
                for (Variable variable : testcase) {
                    JSONObject jsonVar = new JSONObject();
                    jsonVar.put("name", variable.getName());
                    jsonVar.put("type", variable.getType());
                    jsonVar.put("value", variable.getValue());
                    jsonVariables.add(jsonVar);
                }

                jsonTestcase.put("variables", jsonVariables);
                jsonTestcases.add(jsonTestcase);
            }
        }

        String jsonFilePath = "JdtBase/src/test/LoopTestcases.json";
        try (FileWriter file = new FileWriter(jsonFilePath)) {
            file.write(jsonTestcases.toString());
            System.out.println("\nLoop test cases saved to " + jsonFilePath);
        } catch (IOException e) {
            System.err.println("Error writing to JSON file: " + e.getMessage());
        }

        System.out.println("===== LOOP ANALYSIS COMPLETED =====\n");
    }
    private String formatLoopInfo(LoopInfo loopInfo) {
        StringBuilder sb = new StringBuilder();
        sb.append("Loop using variable '").append(loopInfo.getIteratorVariable()).append("' ");
        sb.append("starting at ").append(loopInfo.getStartValue()).append(", ");
        sb.append("ending at ").append(loopInfo.getEndValue()).append(", ");
        sb.append("with step ").append(loopInfo.getStepValue()).append("\n");
        sb.append("  - Max iterations: ").append(loopInfo.getMaxIterations()).append("\n");

        if (loopInfo.getLoopParameter() != null) {
            sb.append("  - Loop is influenced by parameter: ").append(loopInfo.getLoopParameter());
        } else {
            sb.append("  - Loop has fixed bounds (no parameter dependency)");
        }

        return sb.toString();
    }
    private void validateLoopIterations(Method method, List<LoopInfo> loops, List<List<Variable>> testcases) {
        System.out.println("\n===== VALIDATING LOOP ITERATIONS =====");

        // For each test case, attempt to determine the actual loop iterations
        for (List<Variable> testcase : testcases) {
            if (testcase.isEmpty()) continue;

            String expectedIterationsStr = testcase.get(0).getMetadata("expectedIterations");
            if (expectedIterationsStr == null) continue;

            int expectedIterations;
            try {
                expectedIterations = Integer.parseInt(expectedIterationsStr.replace("+", ""));
            } catch (NumberFormatException e) {
                continue; // Skip if can't parse
            }

            System.out.println("Validating test case: " + formatTestCaseDesc(testcase));
            System.out.println("  - Expected iterations: " + expectedIterationsStr);

            // Calculate iterations for this test case
            for (LoopInfo loopInfo : loops) {
                // Tìm giá trị tham số bắt đầu và kết thúc
                Integer startValue = null;
                Integer endValue = null;

                String startParam = loopInfo.getStartParameter();
                String endParam = loopInfo.getLoopParameter();

                // Tìm giá trị thực tế từ testcase
                for (Variable var : testcase) {
                    if (startParam != null && var.getName().equals(startParam)) {
                        startValue = Integer.parseInt(var.getValue());
                    }
                    if (endParam != null && var.getName().equals(endParam)) {
                        endValue = Integer.parseInt(var.getValue());
                    }
                }

                // Nếu không tìm thấy trong test case, sử dụng giá trị mặc định
                if (startValue == null) {
                    startValue = loopInfo.getStartValue();
                }
                if (endValue == null) {
                    endValue = loopInfo.getEndValue();
                }

                // Tính số lần lặp
                int calculatedIterations = 0;
                int step = loopInfo.getStepValue();

                for (int i = startValue; i < endValue; i += step) {
                    calculatedIterations++;
                }

                System.out.println("  - Calculated iterations: " + calculatedIterations);
                System.out.println("  - Validation: " +
                        (calculatedIterations == expectedIterations ? "PASS" : "FAIL"));
            }

            System.out.println();
        }

        System.out.println("===== VALIDATION COMPLETED =====\n");
    }

    private int calculateIterations(LoopInfo loopInfo, int paramValue) {
        int start = loopInfo.getStartValue();
        int step = loopInfo.getStepValue();
        int iterations = 0;

        if (step > 0) {
            // For loops with i++, i+=2, etc.
            for (int i = start; i <= paramValue; i += step) {
                iterations++;
            }
        } else {
            // For loops with i--, i-=2, etc.
            for (int i = start; i >= paramValue; i += step) {
                iterations++;
            }
        }

        return iterations;
    }
    // Thêm phương thức formatTestCaseDesc để hiển thị thông tin testcase
    private String formatTestCaseDesc(List<Variable> testcase) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < testcase.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(testcase.get(i).getName()).append("=").append(testcase.get(i).getValue());
        }
        sb.append("]");
        return sb.toString();
    }

        /**
     * Lấy đường dẫn tệp từ đối tượng Method
     */
    private String extractFilePathFromMethod(Method method) {
        // Ưu tiên sử dụng filePath đã có trong đối tượng Method
        if (method.getFilePath() != null && !method.getFilePath().isEmpty()) {
            return method.getFilePath();
        }
        
        // Nếu không có filePath, thử lấy từ đường dẫn file hiện tại của LFCm
        if (this.filePath != null && !this.filePath.isEmpty()) {
            Path path = Paths.get(this.filePath);
            if (Files.exists(path)) {
                return path.getFileName().toString();
            }
        }
        
        // Nếu không thể xác định, sử dụng tên mặc định
        return "DataTest2.java";
    }
    
    private String getFileNameFromPath(String filePath) {
        // Lấy tên file từ đường dẫn đầy đủ
        int lastSeparatorIndex = Math.max(filePath.lastIndexOf('/'), filePath.lastIndexOf('\\'));
        return filePath.substring(lastSeparatorIndex + 1).replace(".java", "");
    }
    private void generateProjectCoverageReport(Map<String, List<Method>> methodsByFile) {
        System.out.println("\n===== PROJECT COVERAGE SUMMARY =====");
        
        int totalFiles = methodsByFile.size();
        double totalC1Coverage = 0.0;
        double totalC2Coverage = 0.0;
        double totalC3Coverage = 0.0;
        
        // Tính tổng độ phủ trên tất cả các tệp
        for (Map.Entry<String, List<Method>> entry : methodsByFile.entrySet()) {
            FileCoverage fileCoverage = new FileCoverage(entry.getKey(), entry.getValue());
            totalC1Coverage += fileCoverage.getFileCoverage("C1");
            totalC2Coverage += fileCoverage.getFileCoverage("C2");
            totalC3Coverage += fileCoverage.getFileCoverage("C3");
        }
        
        // Tính trung bình
        double avgC1Coverage = totalC1Coverage / totalFiles;
        double avgC2Coverage = totalC2Coverage / totalFiles;
        double avgC3Coverage = totalC3Coverage / totalFiles;
        
        System.out.println("Tổng số tệp: " + totalFiles);
        System.out.println("Độ phủ câu lệnh (C1) trung bình: " + String.format("%.2f%%", avgC1Coverage));
        System.out.println("Độ phủ nhánh (C2) trung bình: " + String.format("%.2f%%", avgC2Coverage));
        System.out.println("Độ phủ điều kiện (C3) trung bình: " + String.format("%.2f%%", avgC3Coverage));
        
        // Tạo JSON tổng hợp
        JSONObject projectCoverageJson = new JSONObject();
        projectCoverageJson.put("totalFiles", totalFiles);
        projectCoverageJson.put("avgC1Coverage", String.format("%.2f%%", avgC1Coverage));
        projectCoverageJson.put("avgC2Coverage", String.format("%.2f%%", avgC2Coverage));
        projectCoverageJson.put("avgC3Coverage", String.format("%.2f%%", avgC3Coverage));
        
        // Lưu kết quả tổng hợp
        String currentPath = Paths.get("").toAbsolutePath().toString()
            .replace("\\", "/") + "/";
        writeFileJson(currentPath + "JdtBase/src/result/ProjectCoverage.json", projectCoverageJson);
    }
    /**
 * Ghi một đối tượng JSON vào tệp
 * @param filepath Đường dẫn tới tệp lưu trữ JSON
 * @param jsonObject Đối tượng JSON cần ghi
 */
private void writeFileJson(String filepath, JSONObject jsonObject) {
    File jsonFile = new File(filepath);
    if (jsonFile.exists()) {
        jsonFile.delete();
    }

    try {
        // Đảm bảo thư mục tồn tại
        File parentDir = jsonFile.getParentFile();
        if (!parentDir.exists()) {
            parentDir.mkdirs();
        }
        
        // Ghi đối tượng JSON vào tệp
        try (FileWriter fileWriter = new FileWriter(jsonFile)) {
            fileWriter.write(jsonObject.toString());
            fileWriter.flush();
        }
    } catch (IOException e) {
        System.err.println("Lỗi khi ghi tệp JSON: " + e.getMessage());
        e.printStackTrace();
    }
}
}
